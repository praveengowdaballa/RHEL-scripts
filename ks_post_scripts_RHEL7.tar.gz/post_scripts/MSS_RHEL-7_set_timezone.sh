#!/bin/bash

#Title:MSS_RHEL-6_set_timezone.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

################## Export PATH #############################

path

##################### Define Variable Here #################


time_zone=`get_user_input "RH_TIMEZONE"`
if [ -z $time_zone ]
then
        cecho " TIMEZONE not set,Hence using default timezone" red
	time_zone="Europe/London"
fi


current_timezone=`timedatectl status |grep -w Timezone|awk -F " " '{print $2}'`
if [ $time_zone = $current_timezone ]
then
        cecho "Already Compliance with Standard... Currently the following timezone set on this system $current_timezone" green
else
        timedatectl set-timezone $time_zone
        if [ $? -eq 0 ];then
        cecho "Timezone setting changed to $time_zone" yellow
        else
        cecho "Failed to change timezone to $time_zone" red
        fi
fi


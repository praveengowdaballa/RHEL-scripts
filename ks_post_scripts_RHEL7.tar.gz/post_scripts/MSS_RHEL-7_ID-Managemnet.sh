#!/bin/bash

#Title:MSS_RHEL-7_ID-Managemnet.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path

check_ppm_users_groups ()
{
groups='s_ppm c_ppm'
users='s_psadmin c_admin1 c_admin2'

for i in $groups
do
egrep "$i" /etc/group > /dev/null
if [ $? -eq 0 ] ; then
   cecho "$i Group Already exists, please check..." green
fi
done

for i in $users
do
egrep "$i" /etc/passwd > /dev/null
if [ $? -eq 0 ] ; then
    cecho "$i User Already exists, please check..." green
fi
done
}

add_ppm_users_groups ()
{
groups='s_ppm c_ppm'
users='s_psadmin c_admin1 c_admin2'

for i in $groups
do
  	egrep "$i" /etc/group > /dev/null
	if [ $? -eq 0 ] ; then
   	cecho "$i Group Already exists, please check..." green
	else
		if [ "$i" = "s_ppm" ];then
		groupadd -g 70022 s_ppm > /dev/null 2> /dev/null
			if [ $? -eq 0 ] ; then
		    	 cecho "$i Group added successfully..." green
			else
		         cecho "Error: $i Group add  failed..."
		         exit 6
	 		fi
				 
		elif [ "$i" = "c_ppm" ];then
		groupadd -g 71022 c_ppm > /dev/null 2> /dev/null
			if [ $? -eq 0 ] ; then
			 cecho "$i Group added successfully..." green
			else
		         cecho "Error: $i Group add  failed..." red
		         exit 6
			fi
		fi	
	fi
done


for i in $users
do
	egrep "$i" /etc/passwd > /dev/null
	if [ $? -eq 0 ] ; then
    	 cecho "$i User Already exists, please check..." green
	 else
		 if [ "$i" = "s_psadmin" ];then
		PASS='S&9injL&2K*aMz4puA#8xwB&dvH7n0'
		
		useradd -u 70023 -g s_ppm -s /bin/sh -c " Hitachi PPM Service Account" -p ${PASS} -d /home/s_psadmin -m s_psadmin > /dev/null 2> /dev/null
		
			if [ $? -eq 0 ] ; then
		   	 chage -M 99999 s_psadmin
		    	 cecho "$i User added sucessfuly..." green
	        	else
		   	 cecho "Error: $i User add  failed..." red
		   	 exit 7
			fi
		elif [ "$i" = "c_admin1" ];then
		  PASS='$1$rXAL3CFW$MtaI6uWpmp.tBdguFIJrt/'
		  
		useradd -u 71023 -g c_ppm -s /bin/sh -c "Hitachi PPM  Managed Admin account" -p ${PASS} -d /home/c_admin1 -m c_admin1 > /dev/null 2> /dev/null
			 if [ $? -eq 0 ] ; then
                         cecho "$i User added sucessfuly..." green
                        else
                         cecho "Error: $i User add  failed..." red
                         exit 7
                        fi
 		elif [ "$i" = "c_admin2" ];then
		 PASS='$1$rXAL3CFW$MtaI6uWpmp.tBdguFIJrt/'

		useradd -u 71024 -g c_ppm -s /bin/sh -c "Hitachi PPM  Managed Admin account" -p ${PASS} -d /home/c_admin2 -m c_admin2 > /dev/null 2> /dev/null
			if [ $? -eq 0 ] ; then
                         cecho "$i User added sucessfuly..." green
                        else
                         cecho "Error: $i User add  failed..." red
                         exit 7
                        fi

	    	fi 
	fi
done
}

add_ppm_users_groups


## Adding the entries in sudo file for granting and restricting access to the above accounts created ##

if [ -f /etc/sudoers ] ; then

		x=0
		y=0
	
	user1=`grep -I c_ppm /etc/sudoers`
		if [ $? -eq 1 ];then
			x=$?
		fi
	user2=`grep -I s_ppm /etc/sudoers`
		 if [ $? -eq 1 ];then
                        y=$?
                fi

	if [  $x -eq 1 ] && [ $y -eq 1  ]; then
   echo "#=================================================================#" >> /etc/sudoers
   echo "#Hitachi PPM Configuration " >> /etc/sudoers
   echo "Cmnd_Alias PASSWD1=/usr/bin/passwd c_admin1" >> /etc/sudoers
   echo "Cmnd_Alias PASSWD2=/usr/bin/passwd c_admin2" >> /etc/sudoers
   echo "###"
   echo "#Restricting users in group s_ppm to run only the above commands" >> /etc/sudoers
   echo "%s_ppm       ALL= NOPASSWD: PASSWD1, PASSWD2" >> /etc/sudoers
   echo "###"
     echo "#Granting users under c_ppm with root access" >> /etc/sudoers
   echo "%c_ppm       ALL=(ALL)    NOPASSWD:   ALL" >> /etc/sudoers
   echo "#=================================================================#" >> /etc/sudoers
	else
	cecho "Users are already in Sudoers file" green
	fi

else

   echo "File doesn't exists..."
   exit 7
fi

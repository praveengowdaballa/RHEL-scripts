#!/bin/bash

#Title:MSS_RHEL-7_disable_ipv6.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path


####################### Define Variable Here #################

    CONFIG_FILE="/etc/modprobe.d/disable-fs.conf"

    DATA_VAR="install cramfs"
    DATA_VAL="/bin/true"
    DELIMITER='  '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

    DATA_VAR="install freevxfs"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

    DATA_VAR="install jffs2"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

    DATA_VAR="install hfs"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

    DATA_VAR="install hfsplus"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

    DATA_VAR="install squashfs"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

    DATA_VAR="install dccp"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"	

    DATA_VAR="install sctp"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

    DATA_VAR="install rds"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

    DATA_VAR="install tipc"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"





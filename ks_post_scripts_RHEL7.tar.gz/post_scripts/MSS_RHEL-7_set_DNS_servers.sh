#!/bin/bash

#Title:MSS_RHEL-6_set_DNS_servers.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

################## Export PATH #############################

path

##################### Define Variable Here #################
CONFIG_FILE="/etc/resolv.conf"
num_fields=2
typeset -i status=0
typeset -i str_pos=0
typeset -i count=0
typeset -i change=0

DATA_VAR="search"
DATA_VAL="cms.colt"
DELIMITER=' '
oldetry=""

DNS_SEARCH_LIST="`get_user_input DNS_SEARCH_LIST`"
if [ -z "$DNS_SEARCH_LIST" ]
then
        cecho " DNS search not set.  Using default..." red
#        cecho "You must now manually set your DNS servers in /etc/resolv.conf file" red
        DNS_SEARCH_LIST="$DATA_VAL"
fi

DATA_VAR="search"
for dns_domain in $DNS_SEARCH_LIST
do
	DATA_VAL="$dns_domain"
	make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"
done

DNS_NAMESERVERS=`get_user_input DNS_NAMESERVERS`
if [ -z "$DNS_NAMESERVERS" ]
then
	cecho " DNS server not set.  Using default..." red
	echo "exiting....."
	exit 1
fi

DATA_VAR="nameserver"
DELIMITER=' '
for nameserver in $DNS_NAMESERVERS
do
	DATA_VAL="$nameserver"
	make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"
done



#!/bin/bash
#Note:27-Nov-2014 Modified functions for RHEL-7 systemd - functions modified are these check_service_existence, check_service_status,switch_on_common_services, switch_off_common_services

##################### PATH ####################################

export PATH=$PATH:/bin:/usr/bin:/sbin:/usr/local:/usr/local/sbin

######################## Functions ##############################

ROOT_DIR="/root/post_scripts"
LOCAL_DEFAULTS="defaults.cfg"
WGET="/usr/bin/wget"
OSFILE='/etc/redhat-release'


#Set environment path

path ()
{
export PATH=$PATH:/bin:/usr/bin:/sbin:/usr/local:/usr/local/sbin
}

#Get the value from config file
get_user_input () {

        input=${1}
        #echo "VALUE=`sed -n 's/$input//p' $LOCAL_DEFAULTS`"
        #cat $LOCAL_DEFAULTS | awk -F= -v val=$input '{print val}'
        if [ ! -f $LOCAL_DEFAULTS ]
        then
                #echo "$LOCAL_DEFAULTS not found."
                exit 1
        else
               val="`grep \"^$input\" $LOCAL_DEFAULTS | awk -F= '{print $2}'`"
		echo "$val"
              # echo "`grep \"$input\" $LOCAL_DEFAULTS | awk -F= '{print $2}'`"
        fi
}

#Seperator

seperator()
{
echo "----------------------------------------------------------------------------------------"
}

#Timestamp Function
timestamp()
{
        echo "`date '+%d-%b-%Y-%H-%M-%S'`"
}

#Copy config file function

copy_config_file()
{
        original_file=$1
        backup_file=$2
        rc=0


        if [ ! -f $original_file ]
        then
                #echo "file $original_file does not exist."
                rc=1
        else

                cp "$original_file" "$backup_file"
                rc=$?
                #if [ $rc != 0 ]
                #then
                #       echo "cp failed.  Cannot copy $original_file to $backup_file"
                #fi
        fi
        echo "$rc"
}

# Get Line number
get_number()
{
        config_file=$1
        string="$2"
        caseinsensitive=$3
        action="$4"
        GREP_MATCH_OPTION="-w"
        typeset -i num=0

        if [ $caseinsensitive = "yes" ]
        then
                GREP_MATCH_OPTION="-i $GREP_MATCH_OPTION"
        fi

        if [ $action = "-c" ]
        then
                GREP_MATCH_OPTION="-c $GREP_MATCH_OPTION"
                num=`cat $config_file | sed 's/^ *//;s/ *$//' | grep $GREP_MATCH_OPTION '^[^#]*'"$string"''`
        elif [ $action = "-n" ]
        then
                GREP_MATCH_OPTION="-n $GREP_MATCH_OPTION"
                num=`cat $config_file | sed 's/^ *//;s/ *$//' | grep $GREP_MATCH_OPTION '^[^#]*'"$string"'' | awk -F: '{print $1}'`
        fi


        echo $num
}
#Update Config File

update_config_file()
{
        config_file=$1
        olddata=$2
        newdata=$3
        caseinsensitive=$4
        linenum=$5
        typeset -i status=0
        case_flag=""

	BACKUP_FILE="$config_file.`timestamp`"
       rc=`copy_config_file $config_file $BACKUP_FILE`

        TEMP_FILE="/tmp/.tmp.`timestamp`"
        if [ $caseinsensitive = "yes" ]
        then
                case_flag="i"
        fi

        cat $config_file | sed ''$linenum's|^[^#]*'"$olddata"'|'"$newdata"'|g'$case_flag'' > "$TEMP_FILE"
        if [ $? != 0 ]
        then
                status=1
        fi

        if [ -f "$TEMP_FILE" -a "$status" = 0 ]
        then
                mv "$TEMP_FILE" "$config_file"
                if [ $? != 0 ]
                then
                        status=0
                fi
        fi
        echo $status
}

insert_line()
{
	config_file=$1
	linenum=$2
	newdata=$3
	typeset -i status=0
  
	TEMP_FILE="/tmp/.tmp.`timestamp`"

	cat $config_file | sed ''$linenum'i\'"$newdata"'' > "$TEMP_FILE"

	if [ $? != 0 ]
	then
		status=1
	fi

	if [ -f "$TEMP_FILE" -a "$status" = 0 ]
	then
		mv "$TEMP_FILE" "$config_file"
		if [ $? != 0 ]
		then
			status=0
		fi
	fi
	echo $status
} 



get_entry()
{
        config_file=$1
        string=$2
        caseinsensitive=$3
        grep_match_option="-w"
        typeset -i entry_count=0

        if [ $caseinsensitive = "yes" ]
        then
                grep_match_option="-i $grep_match_option"
        fi

        echo "`cat $config_file | sed 's/^ *//;s/ *$//' | grep $grep_match_option '^[^#]*'"$string"''`"
}


get_value()
{
entry=$1
sep=$2
fieldnum=$3
#added '$sep' on 19dec2014
#value=`echo $entry | awk -v sep=$sep -v fieldnum=$fieldnum -F"$sep" '{print $fieldnum}'`
value=`echo $entry | awk -v sep='$sep' -v fieldnum=$fieldnum -F"$sep" '{print $fieldnum}' | sed 's/^ *//;s/ *$//'`
echo $value

}

# Check for the existence of the listed commands
# Abort if they all don;t exist
check_for_os_cmd () {

        for cmd in cat grep cut tr $SED
        do
                if [ ! -x $cmd ]
                then
                        echo "$cmd not found."
                        exit 1
                fi
        done
}

# Check what version
# Relies on the exitence of /etc/redhat-release
os_version() {

        if [ ! -f $OSFILE ]
        then
                echo "$OSFILE: not found."
                exit 1
        fi
        cat $OSFILE | tr -s ' ' % | cut -f 7 -d % | cut -f 1 -d  "."
}

is_integer()
{
var=$1

if [ "$var" -eq "$var" ] 2>/dev/null; then
  val=0
  echo $val
else
  val=1
  echo $val
fi
}


#Colour output

cecho(){

black='\E[30;47m'
red='\E[31;47m'
green='\E[32;47m'
yellow='\E[33;47m'
blue='\E[34;47m'
magenta='\E[35;47m'
cyan='\E[36;47m'
white='\E[37;47m'

    local exp=$1;
    local color=$2;
    if ! [[ $color =~ '^[0-9]$' ]] ; then
       case $(echo $color | tr '[:upper:]' '[:lower:]') in
        black) color=0 ;;
        red) color=1 ;;
        green) color=2 ;;
        yellow) color=3 ;;
        blue) color=4 ;;
        magenta) color=5 ;;
        cyan) color=6 ;;
        white|*) color=7 ;; # white or invalid color
       esac
    fi
    tput setaf $color;
    echo $exp;
    tput sgr0;
}

#Modified for RHEL-7 Systemd function,will not work for RHEL-6 and below.
#Chech Service existance
check_service_existence()
{
	myservice=$1
	systemctl list-unit-files -t service | grep ^"$myservice " >/dev/null
	if [ $? != 0 ]
	then
		echo 1
	else
		echo 0
	fi
}
 
#Modified for RHEL-7 Systemd function,will not work for RHEL-6 and below.
#Check Service Status
# myservice defines RH service name
# mystatus - confirm the os 'myservice' service
# 0 - success
# 1 - failure
check_service_status(){
        myservice=$1
        mystatus=$2
	typeset -i rc=1
	typeset -i i=-1

        	retval=`systemctl list-unit-files -t service | grep ^"$myservice " | awk '{print $2}'`
        	if [ "$retval" = "$mystatus" ]
        	then
			rc=0	
			echo $rc
	     	fi
	
	}

#Modified for RHEL-7 Systemd function,will not work for RHEL-6 and below.
#Switch ON Red Hat Services

switch_on_common_services(){
	typeset -i i=-1
        common_services=$1

        for aservice in $common_services
        do
		i=`check_service_existence $aservice`
		if [ $i !=  0 ]
		then
			cecho "$aservice:  unknown service" red
		else
                	mystatus=`check_service_status "$aservice" "disabled"`
                	if [ "$mystatus" = "0" ]
                	then
				cecho "$aservice is getting enabled...." yellow
                        	 systemctl enable $aservice 
			else
				cecho "$aservice already enabled." green
                	fi
                	mystatus=`check_service_status "$aservice" "disabled"`
                	# Is it on?
                	if [ "$mystatus" = "0" ]
                	then
                        	cecho "$aservice is still disabled...enable manually!!!!" red
                        	exit 1
                	fi
		fi
        done
}


#Modified for RHEL-7 Systemd function,will not work for RHEL-6 and below.
# Switches off common Red Hat services

switch_off_common_services(){
        common_services=$1
	typeset -i i=-1

        for aservice in $common_services
        do
 		i=`check_service_existence $aservice`
		if [ $i !=  0 ]
                then
                       cecho "$aservice:  unknown service" red

                else
                	mystatus=`check_service_status "$aservice" "enabled"`
                	if [ "$mystatus" = "0" ]
                	then
				cecho "$aservice is getting disabled...." yellow
                        	systemctl disable $aservice 
			else
				 cecho "$aservice already disabled." green
                	fi
                	mystatus=`check_service_status "$aservice" "enabled"`
                	# Is it on?
                	if [ "$mystatus" = "0" ]
                	then
                        	cecho "$aservice is still on... diable manually!!!" red
                        	exit 1
                	fi
		fi
        done
}

#Create PAM System-auth file

create_file_rhel6()
{

cat <<! > $CONFIG_FILE
#%PAM-1.0
# This file is auto-generated.
# User changes will be destroyed the next time authconfig is run.
auth        required      pam_env.so
auth        required      pam_tally2.so onerr=fail no_magic_root
auth        sufficient    pam_unix.so nullok try_first_pass
auth        requisite     pam_succeed_if.so uid >= 500 quiet
auth        required      pam_deny.so

account     required      pam_unix.so
account     sufficient    pam_localuser.so
account     required      pam_tally2.so deny=5 no_magic_root reset
account     sufficient    pam_succeed_if.so uid < 500 quiet
account     required      pam_permit.so

password    requisite     pam_cracklib.so try_first_pass retry=3 type= minlen=8 lcredit=-1 ucredit=-1 dcredit=-1 ocredit=-1
password    sufficient    pam_unix.so md5 shadow nullok try_first_pass use_authtok remember=20
password    required      pam_deny.so

session     optional      pam_keyinit.so revoke
session     required      pam_limits.so
session     [success=1 default=ignore] pam_succeed_if.so service in crond quiet use_uid
session     required      pam_unix.so
!
chmod 644 $CONFIG_FILE
}



#Check Config file for PAM

check_file()
{
	config_file=$1
	search_line=$2
	line_marker=$3
	whole_string=$4
	search_string=$5
	sep=""
	opt=""
	pam_options=""
	typeset -i change=0
	datavar=""
	typeset -i matched=0
	typeset -i matchvar=0
	typeset -i matchval=0
	
	DATA_VAR="$whole_string"
	action=""
	CONFIG_FILE="$config_file"
	typeset -i str_pos=0

	count=`get_number $CONFIG_FILE "$search_line" "yes" "-c"`
	if [ $count -gt 1 ]
	then
       		cecho "Duplicate entry in $CONFIG_FILE for $DATA_VAR..." red
        	echo "exiting...."
        	exit 1
	fi

	entry=`get_entry $CONFIG_FILE "$search_line" "no"`
	dataval=""
	if [ ! -z "$entry" ]
	then
        	pam_options="`echo $entry | sed -e 's/\('"$search_line"' \)\(.*\)$/\2/'`"
		for opt in $pam_options
        	do
			sep=`echo "$opt" | egrep '='`
			if [ $? = 0 ]
			then
				datavar=`echo "$opt" | awk -F"=" '{print $1}'`
				dataval=`echo "$opt" | awk -F"=" '{print $2}'`
				search_str_var=`echo "$search_string" | awk -F"=" '{print $1}'`
				search_str_val=`echo "$search_string" | awk -F"=" '{print $2}'`
				if [ "$datavar" = "$search_str_var" ]
                		then
					matchvar=1
                        		if [ "$dataval" = "$search_str_val" ]
                        		then
						matchval=1
                        		fi
					break
                		fi
			else
				if [ "$opt" = "$search_string" ]
				then
					matchvar=1
					matchval=1
					break
				fi
			fi
		
        	done

		if [ $matchvar -eq 0 -o $matchval -eq 0  ]
		then
                	BACKUP_FILE="$CONFIG_FILE.`timestamp`"
                	rc=`copy_config_file $CONFIG_FILE $BACKUP_FILE`
                	if [ $rc -ne 0 ]
                	then
				cecho "Backup $CONFIG_FILE failed ..." red
                        	exit 1

                	fi
		fi

		if [ $matchvar -eq 1 -a $matchval -eq 0 ]
		then
			entry=`echo "$entry" | sed 's/'$datavar'.[^ ]*/'$search_string'/g'`
			str_pos=`get_number $CONFIG_FILE "$search_line" "yes" "-n"`
        		updaterc=`update_config_file $CONFIG_FILE "." "$entry" "yes" $str_pos`
			if [ $updaterc -ne 0 ]
			then
				cecho "update $CONFIG_FILE failed." red
				exit 1
			else
				cecho "$CONFIG_FILE Config file Updated with $entry ..." yellow
			fi
		elif [ $matchvar -eq 0 -a $matchval -eq 0 ]
		then
			entry="$entry $search_string"
			str_pos=`get_number $CONFIG_FILE "$search_line" "yes" "-n"`
        		updaterc=`update_config_file $CONFIG_FILE "." "$entry" "yes" $str_pos`
			if [ $updaterc -ne 0 ]
			then
				echo "update_config_file failed."
				exit 1
			else
				cecho "$CONFIG_FILE Config file Updated with $entry ..." yellow
			fi
                else
		cecho " $CONFIG_FILE Already Compliance with Colt Standard - $entry...." green       
		fi
		#cecho " $CONFIG_FILE Already Compliance with Colt Standard - $entry...." green
	else
		str_pos=`get_number $CONFIG_FILE "$line_marker" "yes" "-n"`
		if [ $str_pos -lt 1 ]
               	then
               		cecho "$CONFIG_FILE does not have the expected entries....." red
                       	exit 1
		fi
		exitcode=`insert_line $CONFIG_FILE $str_pos "$DATA_VAR"`
		
		if [ $exitcode -ne 0 ] 
		then
			cecho "Failed to insert line "$DATA_VAR" to $CONFIG_FILE" red
			exit 1
		else
			cecho "$CONFIG_FILE Inserted Line with - $DATA_VAR - sucessfully... " yellow
		fi
		
		cecho " $CONFIG_FILE Already Compliance with Colt Standard ...." green  
	fi
}


check_file_status()
{
	config_file=$1
	search_line=$2
	line_marker=$3
	whole_string=$4
	search_string=$5
	sep=""
	opt=""
	pam_options=""
	typeset -i change=0
	datavar=""
	typeset -i matched=0
	typeset -i matchvar=0
	typeset -i matchval=0
	
	DATA_VAR="$whole_string"
	action=""
	CONFIG_FILE="$config_file"
	typeset -i str_pos=0

	count=`get_number $CONFIG_FILE "$search_line" "yes" "-c"`
	if [ $count -gt 1 ]
	then
       		cecho "Duplicate entry in $CONFIG_FILE for $DATA_VAR..." red
        	echo "exiting...."
        	exit 1
	fi

	entry=`get_entry $CONFIG_FILE "$search_line" "no"`
	dataval=""
	if [ ! -z "$entry" ]
	then
        	pam_options="`echo $entry | sed -e 's/\('"$search_line"' \)\(.*\)$/\2/'`"
		for opt in $pam_options
        	do
			sep=`echo "$opt" | egrep '='`
			if [ $? = 0 ]
			then
				datavar=`echo "$opt" | awk -F"=" '{print $1}'`
				dataval=`echo "$opt" | awk -F"=" '{print $2}'`
				search_str_var=`echo "$search_string" | awk -F"=" '{print $1}'`
				search_str_val=`echo "$search_string" | awk -F"=" '{print $2}'`
				if [ "$datavar" = "$search_str_var" ]
                		then
					matchvar=1
                        		if [ "$dataval" = "$search_str_val" ]
                        		then
						matchval=1
                        		fi
					break
                		fi
			else
				if [ "$opt" = "$search_string" ]
				then
					matchvar=1
					matchval=1
					break
				fi
			fi
		
        	done


		if [ $matchvar -eq 1 -a $matchval -eq 0 ]
		then
			entry=`echo "$entry" | sed 's/'$datavar'.[^ ]*/'$search_string'/g'`
			str_pos=`get_number $CONFIG_FILE "$search_line" "yes" "-n"`
        		#updaterc=`update_config_file $CONFIG_FILE "." "$entry" "yes" $str_pos`
			cecho "Not Compliance with Colt Standard ... Please update $CONFIG_FILE Config file with $entry ..." red
		elif [ $matchvar -eq 0 -a $matchval -eq 0 ]
		then
			entry="$entry $search_string"
			str_pos=`get_number $CONFIG_FILE "$search_line" "yes" "-n"`
	#        		updaterc=`update_config_file $CONFIG_FILE "." "$entry" "yes" $str_pos`
			cecho "Not Compliance with Colt Standard ... Please update $CONFIG_FILE Config file with $entry ..." red
                else
		cecho " $CONFIG_FILE Already Compliance with Colt Standard - $entry...." green       
		fi
		#cecho " $CONFIG_FILE Already Compliance with Colt Standard - $entry...." green
	else
		str_pos=`get_number $CONFIG_FILE "$line_marker" "yes" "-n"`
		if [ $str_pos -lt 1 ]
               	then
               		cecho "$CONFIG_FILE does not have the expected entries....." red
                       	exit 1
		fi
		cecho "Not Compliance with Colt Standard ... Please insert  $CONFIG_FILE Config file with $DATA_VAR " red
#		exitcode=`insert_line $CONFIG_FILE $str_pos "$DATA_VAR"`
		
		
#		cecho " $CONFIG_FILE Already Compliance with Colt Standard ...." green  
	fi

}

#Make Compliant
make_compliant()
{
        config_file=$1
        data_var=$2
        data_val=$3
        delimeter=$4
        num_fields=$5
        caseinsensitive=$6
        save=$7

        typeset -i str_pos=0
        typeset -i rc=0
        typeset -i updaterc=-1
        typeset -i count=0
        typeset exitcode=0


        # Abort if the number of entries is more than 1
        count=`get_number $config_file "$data_var" "yes" "-c"`
        if [ $count -gt 1 ]
        then
                exitcode=1
        else
                # Retrived matched line from config file
                entry=`get_entry ${config_file} "$data_var" "$caseinsensitive"`
                if [ $count -eq 1 -a ! -z "$entry" ]
                then
                        value=`get_value "$entry" "$delimeter" $num_fields`
		
			#Find the value is integer or string: return code 0-integer 1-String	
			val=`is_integer "$value"`
			if [ "$val" -eq "0" ]
			then
				if [ "$value" -eq "$data_val" ]
				then
			#	cecho "Already compliance with standard $data_var$delimeter$data_val" green
				exitcode=6
				fi
			fi

			if [ $val -eq "1" ]
			then
				if [  "$value" == "$data_val" ]
				then
			#		cecho "Already compliance with standard $data_var$delimeter$data_val" green
					exitcode=6	
				fi
			
			fi
                

                # Backup config file if necessary
                #if [ "$value" != "$data_val" -o $count -lt 2 -a $save = "yes" ]
                if [ "$value" != "$data_val" -a "$save" = "yes" ]
                then
                        BACKUP_FILE="$config_file.`timestamp`"
                        rc=`copy_config_file $config_file $BACKUP_FILE`
                fi

                if [ "$save" = "yes" -a $rc != 0 ]
                then
                        exitcode=2
                fi
	fi
#  If no entry found and backup was successfully taken then
                #  add the require entry
                #if [ $count -eq 0 -a $rc = 0 ]
                if [ $count -eq 0 -a $exitcode = 0 ]
                then
			BACKUP_FILE="$config_file.`timestamp`"
                        rc=`copy_config_file $config_file $BACKUP_FILE`
			#Add the entry to config file.
                        echo "$data_var$delimeter$data_val" >> $config_file
                        updaterc=$?
                        if [ $updaterc != 0 ]
                        then
                                exitcode=3
                        fi

                elif [ "$value" != "$data_val" -a $count -eq 1 -a $exitcode = 0 -a $rc = 0 ]
                then
                        str_pos=`get_number $config_file "$data_var" "$caseinsensitive" "-n"`
                        updaterc=`update_config_file $config_file "$data_var.*" "$data_var$delimeter$data_val" "yes" $str_pos`
                        if [ $updaterc = 1 ]
                        then
                                exitcode=4
                        elif [ $updaterc = 2 ]
                        then
                                exitcode=5
                        fi
                #else	
		#	 cecho "Already compliance with standard $data_var$delimeter$data_val" green
			#exitcode=6
                        
                fi
        fi

        # Error handling....
        case $exitcode in
        0)
                cecho "$CONFIG_FILE successfully updated with $DATA_VAR $DATA_VAL." yellow
                return $exitcode
                ;;

        1)
                cecho "Duplicate entry encountered in $config_file for $data_var." red
                cecho "Please login and manually rectify this situation." red
                return $exitcode
                ;;

        2)
                cecho "Failed to backup $config_file" red
                cecho "Aborting...." red
                return $exitcode
                ;;
        3)
                cecho "Failed to update $config_file with relevant entries." red
                cecho "Aborting...." red
                return $exitcode
                ;;
        4)
                cecho "Failed to create temporary file." red
                cecho "Aborting...." red
                return $exitcode
                ;;
	 5)
                cecho "Failed to rename file to $config_file" red
                cecho "Aborting...." red
                return $exitcode
                ;;
	6)
                cecho "Already compliance with standard $data_var$delimeter$data_val" green
                return $exitcode
                ;;


        *)
                ;;
        esac
}


check_compliant()
{
        config_file=$1
        data_var=$2
        data_val=$3
        delimeter=$4
        num_fields=$5
        caseinsensitive=$6
        save=$7

        typeset -i str_pos=0
        typeset -i rc=0
        typeset -i updaterc=-1
        typeset -i count=0
        typeset exitcode=0


        # Abort if the number of entries is more than 1
        count=`get_number $config_file "$data_var" "yes" "-c"`
        if [ $count -gt 1 ]
        then
                exitcode=1
        else
                # Retrived matched line from config file
                entry=`get_entry ${config_file} "$data_var" "$caseinsensitive"`
                if [ $count -eq 1 -a ! -z "$entry" ]
                then
                        value=`get_value "$entry" "$delimeter" $num_fields`

                        #Find the value is integer or string: return code 0-integer 1-String
                        val=`is_integer "$value"`
                        if [ "$val" -eq "0" ]
                        then
                                if [ "$value" -eq "$data_val" ]
                                then
                        #       cecho "Already compliance with standard $data_var$delimeter$data_val" green
                                exitcode=6
				else
				exitcode=8
                                fi
                        fi

                        if [ $val -eq "1" ]
                        then
                                if [  "$value" == "$data_val" ]
                                then
                        #               cecho "Already compliance with standard $data_var$delimeter$data_val" green
                                        exitcode=6
				else
					exitcode=8
                                fi

                        fi

		elif [ -z $entry  ]
			then
				exitcode=8
			else
			
				exitcode=7
                fi
        fi

        # Error handling....
        case $exitcode in
        0)
                cecho "$CONFIG_FILE successfully updated with $DATA_VAR $DATA_VAL." yellow
                return $exitcode
                ;;

        1)
                cecho "Duplicate entry encountered in $config_file for $data_var." red
                cecho "Please login and manually rectify this situation." red
                return $exitcode
                ;;

        2)
                cecho "Failed to backup $config_file" red
                cecho "Aborting...." red
                return $exitcode
                ;;
        3)
                cecho "Failed to update $config_file with relevant entries." red
                cecho "Aborting...." red
                return $exitcode
                ;;
        4)
                cecho "Failed to create temporary file." red
                cecho "Aborting...." red
                return $exitcode
                ;;
         5)
                cecho "Failed to rename file to $config_file" red
                cecho "Aborting...." red
                return $exitcode
                ;;
        6)
                cecho "Already compliance with Colt standard $data_var$delimeter$data_val" green
                return $exitcode
                ;;
	7)
                cecho "Not compliance with Colt standard... Create config file $CONFIG_FILE manually, add this entry \" $data_var$delimeter$data_val \" " red
                return $exitcode
                ;;

	8)
                cecho "Not compliance with Colt standard... Update config file $CONFIG_FILE manually, add this entry \" $data_var$delimeter$data_val \" " red
                return $exitcode
                ;;

        *)
                ;;
        esac
}


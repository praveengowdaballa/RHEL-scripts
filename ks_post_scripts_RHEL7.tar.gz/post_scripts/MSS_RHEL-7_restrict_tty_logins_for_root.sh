#!/bin/bash
#Title:MSS_RHEL-7_restrict_tty_logins_for_root.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

################## Export PATH #############################

path

##################### Define Variable Here #################
CONFIG_FILE="/etc/securetty"
num_fields=1
typeset -i status=0
typeset -i saved=-1
typeset -i change=0

if [ ! -f $CONFIG_FILE ]
then
	touch $CONFIG_FILE
	cecho " $CONFIG_FILE is created"
fi

backup_file=""


for tty in console tty1 tty2 tty3 tty4 tty5 tty6 tty7 tty8 tty9 tty10 tty11 ttyS0 hvc0 hvc1 hvc2 hvc3 hvc4 hvc5 hvc6 hvc7 hvsi0 hvsi1 hvsi2 xvc0
do
		entry=`cat $CONFIG_FILE | grep "$tty"$`
		if [ -z "$entry" ]
		then
			if [ $saved -ne 0 ]
			then
				backup_file="$CONFIG_FILE.`timestamp`"
				saved=`copy_config_file $CONFIG_FILE $backup_file`
			fi
			echo "$tty" >> $CONFIG_FILE
			change=1
		fi
done

if [ $change -eq 0 ]
then
cecho " Already compliance with Colt standard. " green
else
cecho "$CONFIG_FILE is updated..." yellow
fi

# check permission
expected_perm="-rw-------"
current_perm=`stat $CONFIG_FILE`
if [ "$expected_perm" != "$current_perm" ]
then
	chmod 600 $CONFIG_FILE
fi

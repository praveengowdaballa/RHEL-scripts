#!/bin/bash

#Title:MSS_RHEL-7_disable_peer_dns.sh
#Author:saravana.kannayan@colt.net
#Version:1.0
#Note:This will prevent network service from updating /etc/resolv.conf with the DNS servers received from a DHCP server.

############################################################

. functions.sh

#####################Export PATH #############################

path

####################### Define Variable Here #################


num_fields=2
typeset -i status=0

cd /etc/sysconfig/network-scripts
if [ $? != 0 ]
then
	echo
	echo "Cannot change directory to /etc/sysconfig/network-scripts."
	exit 1
fi
for interface in `ls -1 ifcfg-*`
do
	CONFIG_FILE="$interface"
	DATA_VAR="PEERDNS"
	DATA_VAL="NO"

	# Make PEERDNS  compliant,  if necessary
	make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"
done

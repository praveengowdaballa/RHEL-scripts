#!/bin/bash

#Title:MSS_RHEL-7_Standard_Validator.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path


#: <<'END'

###Check-1: Is default password got changed?
seperator

cecho "Check-1: Is default password got changed?" yellow

ROOT_USER_PASSWORD=`get_user_input RH_ROOT_PASSWORD`
if [ -z "$ROOT_USER_PASSWORD" ]
then
        ROOT_USER_PASSWORD="changen0w"
fi


ROOT_USER_LOGIN=`get_user_input RH_USER_LOGIN`
if [ -z "$ROOT_USER_LOGIN" ]
then
        ROOT_USER_LOGIN="root"
fi

if [ ! -f chkpwd ]
then
        cecho "chkpwd not found." red
        echo "exiting....."
        exit 1
fi

echo $ROOT_USER_PASSWORD | ./chkpwd $ROOT_USER_LOGIN
if [ $? = 0 ]
then
cecho "Default Password not Changed ... Not Compliance with Colt Standard" red
cecho " change root password manually using 'passwd' command " 
else
cecho "Default Password got changed... Compliance with Colt Standard" green
fi



#### Check-2: Is timezone changed as per standard?
seperator
cecho "Check-2: Is timezone changed as per standard" yellow

time_zone=`get_user_input "RH_TIMEZONE"`
if [ -z $time_zone ]
then
        cecho " TIMEZONE not set,Hence using default timezone" red
        time_zone="Europe/London"
fi


current_timezone=`timedatectl status |grep -w Timezone|awk -F " " '{print $2}'`
if [ $time_zone = $current_timezone ]
then
        cecho "Already Compliance with Standard... Currently the following timezone set on this system $current_timezone" green
else
	cecho "Not Compliance with Colt Standard.... Do it manually using below command" red
        cecho "timedatectl set-timezone $time_zone" 
fi


#### Check-3: Is System Locale and Keyboard layout changed?
seperator

cecho " Check-3: Is System Locale and Keyboard layout changed? " yellow



KEYTABLE_VAL=`get_user_input "KEYTABLE"`
if [ -z "$KEYTABLE_VAL" ]
then
        cecho "KEYTABLE not set.Hence taking defaults." red
        KEYTABLE_VAL=en_GB.utf8
fi
cecho "$KEYTABLE_VAL" red

KEYMAP_VAL=`get_user_input "KEYMAP"`
if [ -z "$KEYMAP_VAL" ]
then
        cecho "KEYMAP not set.Hence taking defaults." red
        KEYMAP_VAL=uk
fi
cecho "KEYMAP_VAL" red



current_keytable=`localectl status | grep -w "System Locale"|awk -F"=" '{print $2}'`
if [ $KEYTABLE_VAL = $current_keytable ]
then
        cecho "Already Compliance with Standard... Currently the following System Locale set on this system $current_keytable" green
else
	cecho "Not Compliance with Colt Standard... Run the following command to set" red
        cecho "/usr/bin/localectl set-locale LANG=$KEYTABLE_VAL"
fi

current_keymap=`localectl status | grep -w "VC Keymap"|awk -F": " '{print $2}'`
if [ $KEYMAP_VAL = $current_keymap ]
        then
        cecho "Already Compliance with Colt Standard...System Keyboard Layout is set to $current_keymap" green
else
	cecho "Not Compliance with Colt Standard... Run the following command to set" red
        cecho "/usr/bin/localectl set-keymap $KEYMAP_VAL"
fi

###Check-4: Is PEERDNS disabled?
#This will prevent network service from updating /etc/resolv.conf with the DNS servers received from a DHCP server.
seperator
cecho "Check-4: Is PEERDNS disabled" yellow

num_fields=2
typeset -i status=0

cd /etc/sysconfig/network-scripts
if [ $? != 0 ]
then
        echo
        echo "Cannot change directory to /etc/sysconfig/network-scripts."
        exit 1
fi
for interface in `ls -1 ifcfg-*`
do
        CONFIG_FILE="$interface"
        DATA_VAR="PEERDNS"
        DATA_VAL="NO"
# Check  PEERDNS  compliant,  if necessary
        check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"
done

seperator
### Check-5: Is listed services disabled?
cecho "Check-5: Is listed services disabled?" yellow

common_services="abrt-ccpp.service abrt-oops.service abrt-vmcore.service abrt-xorg.service abrtd.service atd.service smartd.service avahi-daemon.service mdmonitor.service "

for aservice in $common_services
do
 i=`check_service_existence $aservice`
                if [ $i !=  0 ]
                then
                        cecho "$aservice:  unknown service" red
                else

			mystatus=`check_service_status "$aservice" "disabled"`
                        if [ "$mystatus" = "0" ]
                        then
                                cecho "Compliance with Colt Standard... $aservice is already disabled...." green
                        else
                                cecho "Not Compliance with Colt Standard... $aservice is enabled. Please disable manually \"systemctl disable $aservice\" " red 
                        fi
		fi
done


seperator
###Check-6: Is listed services enabled?
cecho "Check-6: Is listed services enabled?" yellow


common_services="chronyd.service psacct.service sysstat.service auditd.service"

for aservice in $common_services
do
 i=`check_service_existence $aservice`
                if [ $i !=  0 ]
                then
                        cecho "$aservice:  unknown service" red
                else

                        mystatus=`check_service_status "$aservice" "enabled"`
                        if [ "$mystatus" = "0" ]
                        then
                                cecho "Compliance with Colt Standard... $aservice is already enabled...." green
                        else
                                cecho "Not Compliance with Colt Standard... $aservice is disabled. Please enable manually \"systemctl enable $aservice\" " red
                        fi
                fi
done

seperator
### Check-7: Is Zeroconf disabled?
cecho "Check-7: Is Zeroconf disabled?" yellow

CONFIG_FILE="/etc/sysconfig/network"
num_fields=2
typeset -i status=0
DATA_VAR="NOZEROCONF"
DATA_VAL="yes"
DELIMITER='='

check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL $DELIMITER $num_fields "yes" "yes"


seperator
###Check-8: Is SSH service restricted as per Colt Standard?
cecho "Check-8: Is SSH service restricted as per Colt Standard?" yellow
CONFIG_FILE="/etc/ssh/sshd_config"
num_fields=2
typeset -i status=0

DATA_VAR="PermitRootLogin"
DATA_VAL="no"
DELIMITER=' '

# Make 'PermitRootLogin' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="Protocol"
DATA_VAL="2"
DELIMITER=' '

# Make 'Protocol' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="Banner"
DATA_VAL="/etc/issue"
DELIMITER=' '

# Make 'Banner' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="LogLevel"
DATA_VAL="INFO"
DELIMITER=' '

# Make 'LogLevel' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="X11Forwarding"
DATA_VAL="no"
DELIMITER=' '

# Make 'X11Forwarding' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="MaxAuthTries"
DATA_VAL="3"
DELIMITER=' '
# Make 'MaxAuthTries' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="HostbasedAuthentication"
DATA_VAL="no"
DELIMITER=' '
# Make 'HostbasedAuthentication' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="IgnoreRhosts"
DATA_VAL="yes"
DELIMITER=' '
# Make IgnoreRhosts compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="PermitEmptyPasswords"
DATA_VAL="no"
DELIMITER=' '

# Make 'MaxAuthTries' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="PermitUserEnvironment"
DATA_VAL="no"
DELIMITER=' '

# Make 'PermitUserEnvironment' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="PermitUserEnvironment"
DATA_VAL="no"
DELIMITER=' '

# Make 'PermitUserEnvironment' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="ClientAliveInterval"
DATA_VAL="300"
DELIMITER=' '

# Make 'ClientAliveInterval' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="ClientAliveCountMax"
DATA_VAL="0"
DELIMITER=' '

# Make 'ClientAliveCountMax' compliant,  if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

seperator
#### Check-9: Is ID management users and groups created?
cecho " Check-9: Is ID management users and groups created? " yellow
check_ppm_users_groups ()
{
groups='s_ppm c_ppm'
users='s_psadmin c_admin1 c_admin2'

for i in $groups
do
egrep "$i" /etc/group > /dev/null
if [ $? -eq 0 ] ; then
   cecho "$i Group Already exists, please check..." green
else
	cecho "Not Compliance with Colt,Group $i is not present" red
	cecho "Add Group using following command \"groupadd -g 70022 $i > /dev/null 2> /dev/null\""
fi
done

for i in $users
do
egrep "$i" /etc/passwd > /dev/null
if [ $? -eq 0 ] ; then
    cecho "$i User Already exists, please check..." green
else
	cecho "Not Compliance with Colt,User $i is not present" red
	cecho "Add User using one of the following command "
   cecho "useradd -u 70023 -g s_ppm -s /bin/sh -c \" Hitachi PPM Service Account\" -p ${PASS} -d /home/s_psadmin -m s_psadmin > /dev/null 2> /dev/null\" "
   cecho "useradd -u 71023 -g c_ppm -s /bin/sh -c \"Hitachi PPM  Managed Admin account\" -p ${PASS} -d /home/c_admin1 -m c_admin1 > /dev/null 2> /dev/null\""
   cecho "useradd -u 71024 -g c_ppm -s /bin/sh -c \"Hitachi PPM  Managed Admin account\" -p ${PASS} -d /home/c_admin2 -m c_admin2 > /dev/null 2> /dev/null\""
fi
done
}
check_ppm_users_groups

if [ -f /etc/sudoers ] ; then

                x=0
                y=0

        user1=`grep -I c_ppm /etc/sudoers`
                if [ $? -eq 1 ];then
                        x=$?
                fi
        user2=`grep -I s_ppm /etc/sudoers`
                 if [ $? -eq 1 ];then
                        y=$?
                fi

        if [  $x -eq 1 ] && [ $y -eq 1  ]; then
        cecho "Not Compliance with Colt Standard... Users are not added in Sudoers file... Please include below entry manually in /etc/sudoers " red
   echo "#=================================================================#"
   echo "#Hitachi PPM Configuration " 
   echo "Cmnd_Alias PASSWD1=/usr/bin/passwd c_admin1" 
   echo "Cmnd_Alias PASSWD2=/usr/bin/passwd c_admin2" 
   echo "###"
   echo "#Restricting users in group s_ppm to run only the above commands"
   echo "%s_ppm       ALL= NOPASSWD: PASSWD1, PASSWD2"
   echo "###"
     echo "#Granting users under c_ppm with root access"
   echo "%c_ppm       ALL=(ALL)    NOPASSWD:   ALL" 
   echo "#=================================================================#"
        else
        cecho "Users are already in Sudoers file" green
        fi

else

   echo "File doesn't exists..."
   exit 7
fi

seperator
###Check-10: Is file permission,SUID removal are done as per Standard?

cecho "Check-10: Is file permission,SUID removal are done as per Standard" yellow

XINETD_FILE="/etc/xinetd.conf"
XINETD_DIR="/etc/xinetd.d"
MSGS_FILE="/var/log/messages"



# check file permission for xinetd file/directory
expected_perm="750"
for afile in $XINETD_FILE $XINETD_DIR
do
        current_perm=`stat $afile -c "%a"`
        if [ $current_perm != $expected_perm ]
        then
                 cecho "Not Compliance with Colt Standard... $afile file not set with $expected_perm permission" red
		echo "chmod $expected_perm $afile"
        else
                cecho "$afile file has already $current_perm" green

        fi
done

# check file permission for xinetd file/directory
expected_perm="640"
current_perm=`stat $MSGS_FILE -c "%a"`
if [ $current_perm != $expected_perm ]
then
        cecho "Not Compliance with Colt Standard...$MSGS_FILE file not set with $expected_perm permission" red
       echo "chmod $expected_perm $MSGS_FILE"

else
        cecho "$MSGS_FILE file has already $current_perm" green
fi

# check files ownership
expected_ownership="root:root"
LIST_OF_CONFIG_FILES="/etc/issue /etc/securetty /etc/ssh/sshd_config /etc/resolv.conf /etc/sudoers"
for afile in $LIST_OF_CONFIG_FILES
do
        current_ownership=`stat $afile -c "%U:%G"`
        if [ $current_ownership != "$expected_ownership" ]
        then

                cecho "$afile file not set with $expected_ownership ownership" red
                echo "chown $expected_ownership $afile"
        else
                cecho "$afile file has already $expected_ownership ownership" green
        fi
done


# Fix SUID files
LIST_OF_EXEC_FILES="/bin/mount /bin/umount /bin/ping /bin/traceroute /usr/sbin/usernetctl /usr/bin/at"
for afile in $LIST_OF_EXEC_FILES
do
        setuid_octal=`stat $afile -c "%a" | cut -c 1`
        if [ "$setuid_octal" = "4" ]
        then

                cecho "Not Compliance with Colt Standard...SUID not removed from $afile Please remove from following command" yellow
                echo "chmod u-s $afile"
        else
                cecho "SUID already removed for $afile" green
        fi
done

### Check-11: Is LXPR installed? ###

seperator

cecho "Check-11: Is LXPR installed?" yellow

LXPR_SCRIPT="lxpr"
LXPR_ROOT_DIR="/opt/lxpr"
LXPR_BIN_DIR="$LXPR_ROOT_DIR/bin"

if [ -f "$LXPR_BIN_DIR/$LXPR_SCRIPT" ]
then
        cecho "$LXPR_BIN_DIR/$LXPR_SCRIPT already installed." green
else
	cecho "Not Compliance with Colt Standar... Please install LXPR" red
	
fi


### Check-12:Is Console tty restricted?
seperator
cecho "Check-12:Is Console tty restricted?" yellow

CONFIG_FILE=/etc/systemd/logind.conf
DATA_VAR=NautoVTs
DATA_VAL="3"
DELIMITER='='
num_fields=2

check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL $DELIMITER $num_fields "yes" "yes"

#### Check-13:Is Securetty set as per the Standard
seperator
cecho "Check-13:Is Securetty set as per the Standard ?" yellow

CONFIG_FILE="/etc/securetty"
num_fields=1
typeset -i status=0
typeset -i saved=-1
typeset -i change=0

if [ ! -f $CONFIG_FILE ]
then
        cecho " $CONFIG_FILE is not present... Create and add the required entry" red
fi

backup_file=""


for tty in console tty1 tty2 tty3 tty4 tty5 tty6 tty7 tty8 tty9 tty10 tty11 ttyS0 hvc0 hvc1 hvc2 hvc3 hvc4 hvc5 hvc6 hvc7 hvsi0 hvsi1 hvsi2 xvc0
do
                entry=`cat $CONFIG_FILE | grep "$tty"$`
                if [ -z "$entry" ]
                then
                        cecho "$tty is not present in $CONFIG_FILE" red
			change=1
                fi
done

if [ $change -eq 0 ]
then
cecho " Already compliance with Colt standard. " green
else
cecho "$CONFIG_FILE needs to be updated... above entries..." yellow
fi

#### Check-14: Is Security Banner set?

seperator
cecho "Check-14: Is Security Banner set?" yellow

Configfile=/etc/issue
Tmp_banner=/tmp/issue

###################### Main Function ############# ###########

cat <<! > $Tmp_banner

                          THIS DEVICE IS PART OF A
                               PRIVATE NETWORK

               *************************************************
               * Unauthorised access or use of this equipment  *
               * is prohibited and constitutes an offence under*
               * the Computer Misuse Act 1990.                 *
               * This system is being monitored and logs will  *
               * be used as evidence in court.                 *
               * If you are not authorised to use this system, *
               * Terminate this session now!                   *
               *************************************************
!

diff --brief $Tmp_banner $Configfile >/dev/null
comp_value=$?

if [ $comp_value -eq 1 ]
then
    cecho "Not Compliance with Colt Standard...Content in $Configfile is different...." red
    cecho "Copy this file $Tmp_banner to $Configfile"

    cecho "Change the permission \"chmod 644 $Configfile\""

else
   cecho "Banner is already Compliance with Colt Standard... " green
fi

#### Check-15: Is DNS nameservers are set?
seperator

cecho "Check-15: Is DNS nameservers are set?" yellow

CONFIG_FILE="/etc/resolv.conf"

cecho "Current search domains are set as below" 

search_val=`grep search $CONFIG_FILE`

if [ -z "$search_val" ] ; then
cecho "Not Compliance with Colt Standard.... No search entry in $CONFIG_FILE"
else
cecho "The Following search domains are present in $CONFIG_FILE" green
cecho "$search_val"
fi

nameserver_val=`grep nameserver $CONFIG_FILE`

if [ -z "$nameserver_val" ] ; then
cecho "Not Compliance with Colt Standard.... No nameserver entry in $CONFIG_FILE"
else
cecho "The Following nameserver are present in $CONFIG_FILE" green
cecho "$nameserver_val"
fi

#### Check-16: Is kernel parameter are set as per Colt Standard?
seperator

cecho "Check-16: Is kernel parameter are set as per Colt Standard?" yellow

CONFIG_FILE="/etc/sysctl.conf"
typeset -i num_fields=2
typeset -i exitcode=0
typeset -i status=0

###### Kernel Values #####

tcp_syncookie=1
accept_source_route=0
accept_redirects=0
rp_filter=1
syn_backlog=4096
secure_redirects=0
send_redirects=0


typeset -i status=0

#Enable TCP SYN Cookie Protection
DATA_VAR="net.ipv4.tcp_syncookies"
DATA_VAL="$tcp_syncookie"
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Disable IP Routing
DATA_VAR="net.ipv4.conf.all.accept_source_route"
DATA_VAL="$accept_source_route"
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Disable ICMP redirect acceptance
DATA_VAR="net.ipv4.conf.all.accept_redirects"
DATA_VAL="$accept_redirects"
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

DATA_VAR="net.ipv6.conf.all.accept_redirects"
DATA_VAL="$accept_redirects"
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Enable IP Spoofing Protecttion
DATA_VAR="net.ipv4.conf.all.rp_filter"
DATA_VAL="$rp_filter"
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Increase Syn Backlog connections
DATA_VAR="net.ipv4.tcp_max_syn_backlog"
DATA_VAL="$syn_backlog"
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Allow redirect from local Routers
DATA_VAR="net.ipv4.conf.all.secure_redirects"
DATA_VAL="$secure_redirects"
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Disable Dedicated Router capability
DATA_VAR="net.ipv4.conf.all.send_redirects"
DATA_VAL="$send_redirects"
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

####Check-17: Is MTA Set as per Colt Standard?
seperator
cecho "Check-17: Is MTA Set as per Colt Standard?" yellow

ALTERNATIVES="/usr/sbin/alternatives"

MTA_EXEC="/usr/sbin/sendmail.postfix"

CURR_MTA_EXEC="`$ALTERNATIVES --display mta | grep "link currently points" | awk '{print $NF}'`"

if [ "$MTA_EXEC" != "$CURR_MTA_EXEC" ]
then

	cecho "Mail Transport Agent is pointing to $CURR_MTA_EXEC" red
        cecho "Set the MTA to Colt Standard \"$ALTERNATIVES --set mta \"$MTA_EXEC\""
else

cecho "Mail Transport Agent is already set to $MTA_EXEC" green

fi

####Check-18: Is NTP configured?
seperator
cecho "Check-18: Is NTP configured?" yellow

CONFIG_FILE="/etc/ntp.conf"
num_fields=2
ntp_servers=""


cecho "Current NTP server setting in $CONFIG_FILE are below..."
grep server /etc/ntp.conf |grep -v ^#
#cecho "$ntp_servers" green

		systemctl is-enabled ntpd.service > /dev/null
                if [ $? != 0 ]
                then
                cecho "ntpd.service is disabled..." red
                fi

                systemctl is-active ntpd.service > /dev/null
                if [ $? != 0 ]
                then
                cecho "ntpd.service is stopped..." red
                else
		cecho "If above NTP servers are not correct..Please update the $CONFIG_FILE with appropriate value" 
                cecho "ntpd.service service is running.." green
                fi



###Check-19: Is Syslog server configured?
seperator
cecho "Check-19: Is Syslog server configured?" yellow

CONFIG_FILE="/etc/rsyslog.conf"
SYSLOG_ENTRY="*.info;mail.none;local1.none;local2.none;local3.none;local4.none;local5.none;local6.none;local7.none"
SYSLOG_SERVER="coltmon"

typeset -i num_fields=0
typeset -i i=1
typeset -i notpresent=0
typeset -i newentry=0

        syslog_server="$SYSLOG_SERVER"
        syslog_severity="$SYSLOG_ENTRY"

save="no"
curr_entry=""


#cecho "Configuring rsyslog...." green
if [ -f $CONFIG_FILE ]
then
       # entry=`get_entry ${CONFIG_FILE} "$syslog_server" "yes"`
	entry=`cat /etc/rsyslog.conf | sed 's/^ *//;s/ *$//'|grep -i '^[^#]*coltmon'`
        if [ ! -z "$entry" ]
        then
                curr_entry="${entry}"
                num_fields="`echo $syslog_severity | awk -F";" '{print NF}'`"
                num_fields=`expr $num_fields + 1`
                while [ $i -lt $num_fields ]
                do
                        severity="`echo $syslog_severity | awk -F\";\" -v i=$i '{print $i}'`"
                        check=`echo $entry | grep -w "$severity"`
                        if [ -z "$check" ]
                        then
                                notpresent=1
                        fi

                        if [ "$notpresent" = 1 ]
                        then
                                entry="${severity};${entry}"
				cecho "$severity is missing from $CONFIG_FILE entry" red
                                notpresent=0
                                newentry=1
                        fi
                        i=`expr $i + 1`
                done
                        if [ "$newentry" = 1 ]
                        then
			cecho "Not Compliance with Colt Standard... Please Check and update $CONFIG_FILE with $SYSLOG_ENTRY" red
			else
                        cecho "Already Compliance with Colt Standard ....$curr_entry " green
			fi
        else
		cecho "Currently there is no entry in $CONFIG_FILE, Please update with correct entry.." red 
		cecho "Update the $CONFIG_FILE with following entry $SYSLOG_ENTRY@$SYSLOG_SERVER -XX"
        fi
else
        cecho "$CONFIG_FILE does not exist." red
fi


###Check-20:  Is Ctrl-alt-del combination disabled?
seperator

cecho "Check-20:  Is Ctrl-alt-del combination disabled?" yellow

check=`systemctl list-unit-files |grep del |awk '{print $2}'`

        if [ $check = masked ]
                then
                cecho "ctrl-alt-del target is already masked....Compliance with Colt Standard" green
                else
                cecho "ctrl-alt-del target is not masked.. Not Compliance with Colt Standard" red
		cecho "  #Note: Run following command to Masking the ctrl-alt-del service
                         'ln -sf /dev/null /etc/systemd/system/ctrl-alt-del.target' "
        fi
##
seperator

###Check-21: Is IPV6 disabled?
cecho "Check-21: Is IPV6 disabled?" yellow

    CONFIG_FILE="/etc/sysctl.d/disable-ipv6.conf"
    DATA_VAR="net.ipv6.conf.all.disable_ipv6"
    DATA_VAL="1"
    DELIMITER=" = "
    num_fields=2


check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL $DELIMITER $num_fields "yes" "yes"

#### Check-22: Is TMOUT and Umask value set?
seperator
cecho "Check-22: Is TMOUT and Umask value set?" yellow
CONFIG_FILE="/etc/profile"
DATA_VAL="trap \"\" 1 2 3 15"

grep -w "SCREENEXEC" $CONFIG_FILE > /dev/null
if [ $? -eq 1 ]
then
cecho "Not Compliance with Colt Standard... Please Update config file $CONFIG_FILE for timeout setting" red
cecho "sed -i.bak-`timestamp` '1i\'\"$DATA_VAL\"'\' $CONFIG_FILE"

echo "cat <<! > $CONFIG_FILE 
SCREENEXEC="screen"
if [ -w $(tty) ]; then 
trap \"exec $SCREENEXEC\" 1 2 3 15 
echo -n 'Starting session in 10 seconds' 
sleep 10 
exec $SCREENEXEC 
fi 
! "

#cat $TMP_FILE
else

cecho "Timeout Already Compliance with Colt Standard..." green

fi

typeset -i count=0
typeset -i linenumber=0

if [ -f $CONFIG_FILE ];then
        ExpectedValue="umask 027"
        Currentvalue=`grep -e "umask 022" -e "umask 027" $CONFIG_FILE |sed -e 's/^[ \t]*//'|uniq`
                if [ "$Currentvalue" != "$ExpectedValue" ]
                then
                        cecho "Not Compliance with Colt Standard... Please Update Config file $CONFIG_FILE ... with $ExpectedValue " red
                       cecho " sed -i -e 's/022/027/g' $CONFIG_FILE
                sed -i.bak.`timestamp` -e 's/002/027/g' $CONFIG_FILE"
                elif [ "$Currentvalue" == "$ExpectedValue" ]
                then
                cecho "Umask value already restricted to $Currentvalue" green
                else
                cecho "Console Currently having this setting $Currentvalue" red 
                fi
else
echo "Config file $file not present"
fi



#### Check-23: Is PAM_TALLY2  authentication restricted
seperator
cecho "Check-23: Is PAM_TALLY2  authentication restricted?" yellow

CONFIG_FILE1="/etc/pam.d/system-auth"
CONFIG_FILE2="/etc/pam.d/password-auth"
BACKUP_FILE=""
TEMP_FILE=""
typeset -i exitcode=0
OSFILE="/etc/redhat-release"



num_fields=2
typeset -i status=0

val=`os_version`


#Create  /etc/security/access-cron.conf, if necessary.  Stops crond from complaining
if [ ! -f /etc/security/access-cron.conf ]
then
	cecho "/etc/security/access-cron.conf file not present,Please create..." red
       echo "touch /etc/security/access-cron.conf"
else
        cecho "/etc/security/access-cron.conf already exist." green
        echo
fi

if [ ! -f $CONFIG_FILE1 ]
then
        $CONFIG_FILE="$CONFIG_FILE1"
        if [ "$val" = "7" ]
        then
               cecho "$CONFIG_FILE is not present...hence it's created it " red
        fi
fi

if [ ! -f $CONFIG_FILE2 ]
then
        $CONFIG_FILE="$CONFIG_FILE2"
        if [ "$val" = "7" ]
        then
               cecho "$CONFIG_FILE2 is not present...hence it's created it " red
        fi
fi



if [ "$val" = "7" ]
then
        DATA_LINE="auth        required      pam_tally2.so deny=5 onerr=fail unlock_time=600"
        search_line="auth.*required.*pam_tally2.so"
        line_marker="auth.*sufficient.*nullok"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "deny=5"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "onerr=fail"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "unlock_time=600"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "deny=5"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "onerr=fail"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "unlock_time=600"

        DATA_LINE="account     required      pam_tally2.so"
        search_line="account.*required.*pam_tally2.so"
        line_marker="account.*required.*pam_unix.so"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "pam_tally2.so"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "pam_tally2.so"


        DATA_LINE="password    required     pam_pwquality.so try_first_pass local_users_only retry=3 authtok_type= minlen=8 lcredit=-1 ucredit=-1 dcredit=-1 ocredit=-1"
        search_line="password.*requisite.*pam_pwquality.so"
        line_marker="password.*sufficient.*pam_unix.so"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "retry=3"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "minlen=8"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "lcredit=-1"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "ucredit=-1"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "dcredit=-1"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "ocredit=-1"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "retry=3"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "minlen=8"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "lcredit=-1"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "ucredit=-1"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "dcredit=-1"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "ocredit=-1"

        DATA_LINE="password    sufficient    pam_unix.so md5 shadow nullok try_first_pass use_authtok remember=20"
        search_line="password.*sufficient.*pam_unix.so"
        line_marker="password.*required.*pam_deny.so"
        check_file_status $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "remember=20"
        check_file_status $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "remember=20"

        # For cron

        CONFIG_FILE="/etc/pam.d/crond"
        DATA_LINE="account    required   pam_listfile.so onerr=succeed item=user sense=allow file=/etc/security/access-cron.conf"
        search_line="account.*required.*pam_listfile.so"
        line_marker="account.*include.*password-auth"
        check_file_status $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "file=/etc/security/access-cron.conf"

        DATA_LINE="account    sufficient pam_succeed_if.so use_uid quiet uid = 0"
        search_line="account.*sufficient.*pam_succeed_if.so"
        line_marker="account.*required.*pam_listfile.so"
        check_file_status $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "use_uid"
        check_file_status $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "quiet"

        # For sshd
        CONFIG_FILE="/etc/pam.d/sshd"
        DATA_LINE="account    required     pam_access.so"
        search_line="account.*required.*pam_access.so"
        line_marker="account.*required.*pam_nologin.so"
        check_file_status $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "pam_access.so"


	# Passwd PAM pwquality setting
        CONFIG_FILE="/etc/pam.d/passwd"
        DATA_LINE="password   required     pam_pwquality.so retry=3"
        search_line="password.*required.*pam_pwquality.so"
        line_marker="password.*substack.*system-auth"
        check_file_status $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "retry=3"

fi
###Check-24: Is Password Quality restricted?
seperator
cecho "Check-24: Is Password Quality restricted?" yellow

CONFIG_FILE="/etc/login.defs"
Delimeter=' '
num_fields=2

PASS_MAX_DAYS_VAL="180"
PASS_MIN_DAYS_VAL="7"
PASS_MIN_LEN_VAL="8"
PASS_WARN_AGE_VAL="8"
PASS_MAX_DAYS_VAR="PASS_MAX_DAYS"
PASS_MIN_DAYS_VAR="PASS_MIN_DAYS"
PASS_MIN_LEN_VAR="PASS_MIN_LEN"
PASS_WARN_AGE_VAR="PASS_WARN_AGE"


DATA_VAR="$PASS_MAX_DAYS_VAR"
DATA_VAL="$PASS_MAX_DAYS_VAL"
DELIMITER=' '

# Check and make PASS_MAX_DAYS is compliant, if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="$PASS_MIN_DAYS_VAR"
DATA_VAL="$PASS_MIN_DAYS_VAL"

# Check and make PASS_MIN_DAYS is compliant, if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="$PASS_MIN_LEN_VAR"
DATA_VAL="$PASS_MIN_LEN_VAL"
DELIMITER=' '

#set -x
# Check and make PASS_MIN_LEN is compliant, if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="$PASS_WARN_AGE_VAR"
DATA_VAL="$PASS_WARN_AGE_VAL"
DELIMITER=' '

# Check and make PASS_WARN_AGE is compliant, if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


CONFIG_FILE="/etc/security/pwquality.conf"
Delimeter=' = '
num_fields=2

MINLEN_VAR="minlen"
DCREDIT_VAR="dcredit"
UCREDIT_VAR="ucredit"
LCREDIT_VAR="lcredit"
#OCREDIT_VAR="ocredit"

MINLEN_VAL="8"
DCREDIT_VAL="1"
UCREDIT_VAL="1"
LCREDIT_VAL="1"
#OCREDIT_VAL="1"


DATA_VAR="$MINLEN_VAR"
DATA_VAL="$MINLEN_VAL"
DELIMITER=" = "

# Check and make MINLEN is compliant, if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' = ' $num_fields "yes" "yes"


DATA_VAR="$DCREDIT_VAR"
DATA_VAL="$DCREDIT_VAL"
DELIMITER=" = "

# Check and make DCREDIT is compliant, if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' = ' $num_fields "yes" "yes"

DATA_VAR="$UCREDIT_VAR"
DATA_VAL="$UCREDIT_VAL"
DELIMITER=' = '

# Check and make UCREDIT is compliant, if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' = ' $num_fields "yes" "yes"

DATA_VAR="$LCREDIT_VAR"
DATA_VAL="$LCREDIT_VAL"
DELIMITER=' = '

# Check and make LCREDIT is compliant, if necessary
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' = ' $num_fields "yes" "yes"


#### Check-25: Is SNMP enabled with community string?
seperator

cecho "Check-25: Is SNMP enabled with community string?" yellow

# Finally check if SNMP is installed properly on the OS
if [ ! -f /etc/snmp/snmpd.conf ]  ; then
   cecho 'Error: SNMP may not be installed properly... /etc/snmp/snmpd.conf missing ' red

else
        ## Check if group exists.. If present we will exit...
        egrep "s_monitor" /etc/group > /dev/null
        if [ $? -eq 0 ] ; then
        cecho "s_monitor Group exists..." green
        else
		  cecho "s_monitor Group not exists... Please create it" red
		  ## Add the group ....
	          cecho "groupadd -g 80022 s_monitor"
        fi

        ## Check if user exists.. If present we will exit...
        egrep "s_monitor" /etc/passwd > /dev/null
        if [ $? -eq 0 ] ; then
  	         cecho "s_monitor User exists..." green
        else
                 cecho "useradd -u 80023 -g s_monitor -s /bin/bash -c "COLT HP" -d /home/s_monitor -m s_monitor" red
        fi

        # Make the snmpd.cond changes
        egrep "rocommunity Monitor" /etc/snmp/snmpd.conf > /dev/null
        if [ $? -eq 0 ]
        then
              cecho "Already Compliance with Colt Standard with Community String \" rocommunity Monitor \"... " green
        else

              cecho "Add community string \" rocommunity Monitor \" to /etc/snmp/snmpd.conf " red
              echo "rocommunity Monitor >> /etc/snmp/snmpd.conf"
        fi
fi


seperator
cecho "Check-26: Is Aide installed and configured?" yellow

CRON_FILE="/var/spool/cron/root"

 if rpm -q aide > /dev/null;then

val=`grep -w "/usr/sbin/aide" $CRON_FILE | grep -v ^"#"`
if [ $? != 0 ]
then
        cecho "Not Compliance with Colt Security Standard, Add Cronjob for file integrity check" red
        #Job scheduled to run the aide check.
    echo"echo "0 5 * * * /usr/sbin/aide --check" >> $CRON_FILE"

else
        cecho "Already Compliance with Colt Standard" green
        echo "$val"

fi
else
cecho "aide is not installed" red
fi

#### Check-27: Is unwanted modles diabled in modprobe?
seperator

cecho " Check-27: Is unwanted modles diabled in modprobe?" yellow

CONFIG_FILE="/etc/modprobe.d/disable-fs.conf"

    DATA_VAR="install cramfs"
    DATA_VAL="/bin/true"
    DELIMITER='  '
    num_fields=2
	if grep -q "$DATA_VAR $DATA_VAL" $CONFIG_FILE; then
	cecho "Compliance with Colt Standard, \"$DATA_VAR  $DATA_VAL\" present in $CONFIG_FILE" green
	else
	cecho "Not Compliance with Colt Standard, Add \"$DATA_VAR $DATA_VAL\"  in $CONFIG_FILE" red
	fi

    DATA_VAR="install freevxfs"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
	if grep -q "$DATA_VAR $DATA_VAL" $CONFIG_FILE; then
        cecho "Compliance with Colt Standard, \"$DATA_VAR  $DATA_VAL\" present in $CONFIG_FILE" green
        else
        cecho "Not Compliance with Colt Standard, Add \"$DATA_VAR $DATA_VAL\"  in $CONFIG_FILE" red
        fi

    DATA_VAR="install jffs2"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
	if grep -q "$DATA_VAR $DATA_VAL" $CONFIG_FILE; then
        cecho "Compliance with Colt Standard, \"$DATA_VAR  $DATA_VAL\" present in $CONFIG_FILE" green
        else
        cecho "Not Compliance with Colt Standard, Add \"$DATA_VAR $DATA_VAL\"  in $CONFIG_FILE" red
        fi

    DATA_VAR="install hfs"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
	if grep -q "$DATA_VAR $DATA_VAL" $CONFIG_FILE; then
        cecho "Compliance with Colt Standard, \"$DATA_VAR  $DATA_VAL\" present in $CONFIG_FILE" green
        else
        cecho "Not Compliance with Colt Standard, Add \"$DATA_VAR $DATA_VAL\"  in $CONFIG_FILE" red
        fi
    DATA_VAR="install hfsplus"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
	if grep -q "$DATA_VAR $DATA_VAL" $CONFIG_FILE; then
        cecho "Compliance with Colt Standard, \"$DATA_VAR  $DATA_VAL\" present in $CONFIG_FILE" green
        else
        cecho "Not Compliance with Colt Standard, Add \"$DATA_VAR $DATA_VAL\"  in $CONFIG_FILE" red
        fi

    DATA_VAR="install squashfs"
    DATA_VAL="/bin/true"
    DELIMITER=' '
    num_fields=2
	if grep -q "$DATA_VAR $DATA_VAL" $CONFIG_FILE; then
        cecho "Compliance with Colt Standard, \"$DATA_VAR  $DATA_VAL\" present in $CONFIG_FILE" green
        else
        cecho "Not Compliance with Colt Standard, Add \"$DATA_VAR $DATA_VAL\"  in $CONFIG_FILE" red
        fi


####Check-28: Disable Restrict Core dump?
seperator
cecho "Check-28: Disable Restrict Core dump?" yellow

CONFIG_FILE="/etc/sysctl.conf"
typeset -i num_fields=2
typeset -i exitcode=0
typeset -i status=0

core_dumps="0"
DATA_VAR="fs.suid_dumpable"
DATA_VAL="$core_dumps"
check_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

####Check-29: Core dump limit
seperator
cecho " Is Core dump limit set? " yellow
    CONFIG_FILE="/etc/security/limits.conf"
    DATA_VAR="* hard core 0"

        grep "* hard core" /etc/security/limits.conf > /dev/null

    if [ $? -eq 1 ]
        then
                cecho "Update $CONFIG_FILE" yellow
                echo "sed -i.bak '$ i\'"$DATA_VAR"'' $CONFIG_FILE"
        else
                cecho "Already Compliance with Colt standard, $DATA_VAR is present in $CONFIG_FILE." green
    fi


##### Check-30: Is Daemon umask set?
seperator
cecho "Check-30: Is Daemon umask set?" yellow
CONFIG_FILE="/etc/sysconfig/init"
exp_val="027"
if grep --silent ^umask $CONFIG_FILE;then

        val=`grep "umask 027" $CONFIG_FILE |awk '{print $2}'`

        if [ $val -ne $exp_val ];
        then
                cecho "Update $CONFIG_FILE with umask 027..." yellow
                echo "sed -i 's/^umask.*/umask 027/g' $CONFIG_FILE"
        else
                cecho "Daemon Umask value already set as \"027\" Compliance with Colt Standard" green
        fi
else
cecho "Update $CONFIG_FILE with umask 027..." yellow
fi

##### Check-31: Upgrade Password Hashing Algorithm to SHA-512
seperator
cecho " Check-31: Is Password Hashing Algorithm updated to SHA-512" yellow

if ! grep -q "^password.*sufficient.*pam_unix.so.*sha512" /etc/pam.d/system-auth; then
        cecho "Update Password Hashing Algorithm to SHA-512" yellow
        echo "sed -i --follow-symlink "/^password.*sufficient.*pam_unix.so/ s/md5/sha512/" /etc/pam.d/system-auth"
       echo "sed -i --follow-symlink "/^password.*sufficient.*pam_unix.so/ s/md5/sha512/" /etc/pam.d/password-auth"

else
        cecho "Already Compliance with Colt Standard, Password Hashing Algorithm is SHA-512" green
fi


##### Check-32: CIS-7.4 Set Default umask for Users
seperator
cecho "Check-32: CIS-7.4 Set Default umask for Users" yellow
CONFIG_FILE="/etc/bashrc"
exp_val="077"
if grep --silent ^umask $CONFIG_FILE;then

        val=`grep "umask $exp_val" $CONFIG_FILE |awk '{print $2}'`

        if [ $val -ne $exp_val ];
        then
                cecho "Update $CONFIG_FILE with umask $exp_val ..." yellow
                echo "sed -i 's/^umask.*/umask '$exp_val'/g' $CONFIG_FILE"
        else
                cecho "Daemon Umask value already set as \"$exp_val\" Compliance with Colt Standard" green
        fi
else
cecho "Update $CONFIG_FILE with umask $exp_val ..." yellow
fi

##### Check-33: 7.5 Lock Inactive User Accounts
seperator
cecho "Check-33: CIS-7.5, Lock Inactive User Accounts" yellow
CONFIG_FILE="/etc/default/useradd"
if ! grep -q "^INACTIVE=35" $CONFIG_FILE; then
cecho "Update Lock Inactive User Accounts to 35 days"
echo "sed -i "/^INACTIVE.*/ s/INACTIVE.*/INACTIVE=35/" $CONFIG_FILE"
else
        cecho "Already Compliance with Colt Standard, Lock Inactive=35 " green
fi



#!/bin/bash

. functions.sh

#Pre Install script

export PATH=$PATH:/bin:/usr/bin:/sbin:/usr/local:/usr/local/sbin:/usr/sbin

# Create xymon user if needed
id -u xymon >/dev/null 2>&1
if [ $? != 0 ]
then
        # I want to use 1985 or else I'll sulk
        useradd -u 1986 -G adm -c "xymon COLT Monitor User" xymon
        if [ $? != 0 ]
        then
                echo "user xymon not present.Please check"
                echo "exiting ...."
                exit 1
                    fi
fi
#Commenting requiretty from sudoers file
cat /etc/sudoers | sed 's/Defaults    requiretty/#Defaults    requiretty/g' > /tmp/sudoers
mv /tmp/sudoers /etc/sudoers
chmod 0440 /etc/sudoers


## Adding the entries in sudo file for granting and restricting access to the above accounts created ##

if [ -f /etc/sudoers ] ; then

                x=0

        user1=`grep -I xymon /etc/sudoers`
                if [ $? -eq 1 ];then
                        x=$?
                fi

        if [  $x -eq 1 ]; then


        ## Read drop-in files from /etc/sudoers.d (the # here does not mean a comment)
#includedir /etc/sudoers.d

echo "#Hobbit Network" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /usr/sbin/ethtool" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /sbin/ethtool" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /sbin/mii-tool" >> /etc/sudoers
echo "#Hobbit Hardware" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /sbin/hplog" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /sbin/hpasmcli" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /usr/sbin/hpacucli" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /opt/HPQhealth/sbin/hpasmcli" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /opt/HPQacucli/sbin/hpacucli" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /usr/local/sbin/array-info" >> /etc/sudoers
echo "#Hobbit client ext plugins" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /sbin/drbdadm dstate" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /sbin/drbdadm cstate" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /sbin/drbdadm state" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /sbin/powermt" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /usr/sbin/pvdisplay" >> /etc/sudoers
echo "xymon    ALL=NOPASSWD: /usr/sbin/crm_mon" >> /etc/sudoers
 else
        cecho "Users are already in Sudoers file" green
 fi


fi

#Install Hobbit


val=`os_version`
echo $val


if [ $val == 7 ]
then
    HB_RPM="xymon-client-4.3.18-1.x86_64.rpm"
fi

HB_Local_DIR="/ColtExtras"

HB_DIR="ColtExtras_RHEL65/"

# Get software server IP and root directory

if [ -f $HB_Local_DIR/$HB_RPM ]
then
install_source=$HB_Local_DIR/$HB_RPM
else
prov_server=`get_user_input prov_server`
if [ -z "$prov_server" ]
then
        cecho "prov_server not set in defaults.cfg.  Aborting..." red
        cecho "You must now manually install hobbit..." red
        exit 1
fi

install_source=`echo "ftp://$prov_server/$HB_DIR/$HB_RPM"`
fi

rc=`rpm -q xymon-client`

if [ $? -eq 1  ]
then
rpm -ivh --nodeps $install_source
        if [ $? != 0 ]
        then
        cecho "$HB_RPM: failed to install" red
        else
        cecho "$HB_RPM: installed." green
        fi

else
cecho "$HB_RPM is already installed" green
fi


#Post Install Hobbit


CONFIG_FILE="/etc/sysconfig/xymon-client"
num_fields=2
typeset -i status=0

if [ ! -f $CONFIG_FILE ]
then
      echo "$CONFIG_FILE does not exist."
      exit 1
fi

MONITORING_SERVER="`get_user_input MONITORING_SERVER`"
if [ -z "$MONITORING_SERVER" ]
then
        echo "$0: MONITORING Server not set."
        exit 1
fi

DATA_VAR="BBDISP"
DATA_VAL="$MONITORING_SERVER"
DELIMITER='='

# Configure the monitoring server
make_compliant $CONFIG_FILE "$DATA_VAR" "$DATA_VAL" '=' $num_fields "yes" "yes"


 # Enable the service
                systemctl is-enabled xymon-client.service > /dev/null
                if [ $? != 0 ]
                then
                cecho "xymon-client.service is disabled... enabling.." yellow
                systemctl enable xymon-client.service
                fi

                systemctl is-active xymon-client.service > /dev/null
                if [ $? != 0 ]
                then
                cecho "xymon-client.service is stopped...Staring" yellow
                systemctl start xymon-client.service
                else
                cecho "restarting xymon-client.service service..." yellow
                systemctl restart xymon-client.service
                fi


#!/bin/bash

. functions.sh

#Pre Install script

export PATH=$PATH:/bin:/usr/bin:/sbin:/usr/local:/usr/local/sbin:/usr/sbin

# Create hobbit user if needed
id -u hobbit >/dev/null 2>&1
if [ $? != 0 ]
then
        # I want to use 1985 or else I'll sulk
        useradd -u 1985 -G adm -c "Hobbit COLT Monitor User" hobbit
        if [ $? != 0 ]
        then
                echo "user hobbit not present."
                echo "exiting ...."
                exit 1
                    fi
fi
#Commenting requiretty from sudoers file
cat /etc/sudoers | sed 's/Defaults    requiretty/#Defaults    requiretty/g' > /tmp/sudoers
mv /tmp/sudoers /etc/sudoers
chmod 0440 /etc/sudoers


#Install Hobbit


val=`os_version`
echo $val


if [ $val == 7 ]
then
    HB_RPM="xymon-client-4.3.18-1.x86_64.rpm"
fi

HB_Local_DIR="/ColtExtras"

HB_DIR="ColtExtras_RHEL65/"

# Get software server IP and root directory

if [ -f $HB_Local_DIR/$HB_RPM ]
then
install_source=$HB_Local_DIR/$HB_RPM
else
prov_server=`get_user_input prov_server`
if [ -z "$prov_server" ]
then
        cecho "prov_server not set in defaults.cfg.  Aborting..." red
        cecho "You must now manually install hobbit..." red
        exit 1
fi

install_source=`echo "ftp://$prov_server/$HB_DIR/$HB_RPM"`
fi

rc=`rpm -q $HB_RPM`

if [ $? -eq 1  ]
then
rpm -ivh --nodeps $install_source
        if [ $? != 0 ]
        then
        cecho "$HB_RPM: failed to install" red
        else
        cecho "$HB_RPM: installed." green
        fi

else
cecho "$HB_RPM is already installed" green
fi


#Post Install Hobbit


CONFIG_FILE="/usr/lib/hobbit/client/etc/hobbitclient.cfg"
num_fields=2
typeset -i status=0

if [  -f /usr/lib/hobbit/client/etc/hobbitclient.cfg.DIST -a ! -f $CONFIG_FILE ]
then
        cp /usr/lib/hobbit/client/etc/hobbitclient.cfg.DIST $CONFIG_FILE
fi

if [ ! -f $CONFIG_FILE ]
then
      echo "$CONFIG_FILE does not exist."
      exit 1
fi

MONITORING_SERVER="`get_user_input MONITORING_SERVER`"
if [ -z "$MONITORING_SERVER" ]
then
        echo "$0: MONITORING Server not set."
        exit 1
fi

DATA_VAR="BBDISP"
DATA_VAL="$MONITORING_SERVER"
DELIMITER='='

# Configure the monitoring server
make_compliant $CONFIG_FILE "$DATA_VAR" "$DATA_VAL" '=' $num_fields "yes" "yes"

# Fix up the perms of the /etc files
if [ -f /etc/init.d/hobbit-client ]
then
 chown root:root /etc/init.d/hobbit-client

 # Enable the service
 chmod +x /etc/init.d/hobbit-client
 chkconfig --add hobbit-client
 chkconfig hobbit-client on
id -u hobbit >/dev/null 2>&1
if [ $? = 0 ]
then
   chown -R hobbit:hobbit /usr/lib/hobbit
fi

# Start hobbit-client
 service hobbit-client start
else
    echo "/etc/init.d/hobbit-client does not exist."
    echo "hobbit-client may not have installed properly."
    exit 1
fi


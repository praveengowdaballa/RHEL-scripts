#!/bin/bash
#Author: Saurabh Srivastava, Infosys - saurabh_srivastava13@infosys.com
#
# Dated: 1st July 2010
#
# Description: This script will create PPM solution user account on customer servers

### PPM Solution User Account Creation (on customer servers) ####

# Adding PATH information.

addToPath() {
        WRK_PATH=":${PATH}:"
        echo $WRK_PATH | grep ":$1:" 2>&1 1>/dev/null
        if [ $? -eq 0 ]; then
                echo $PATH
        else
                echo "$PATH:$1"
        fi
}

# Stuff that is needed
PATH=`addToPath /usr/bin`
PATH=`addToPath /usr/sbin`
PATH=`addToPath /bin`
PATH=`addToPath /sbin`
WHICH=`which which`; [ $? -eq 0 ] || WHICH=/usr/bin/which
export PATH WHICH


## Check if s_ppm group exists.. If present we will exit...

egrep "s_ppm" /etc/group > /dev/null
if [ $? -eq 0 ] ; then
    echo "Group exists, please check..."
    exit 3
fi


## Check if c_ppm group exists.. If present we will exit...

egrep "c_ppm" /etc/group > /dev/null
if [ $? -eq 0 ] ; then
    echo "Group exists, please check..."
    exit 3
fi


## Check if s_psadmin user exists.. If present we will exit...

egrep "s_psadmin" /etc/passwd > /dev/null
if [ $? -eq 0 ] ; then
   echo "User exists"
   exit 4
fi


## Check if c_admin1 user exists.. If present we will exit...

egrep "c_admin1" /etc/passwd > /dev/null
if [ $? -eq 0 ] ; then
   echo "User exists"
   exit 4
fi


## Check if c_admin2 user exists.. If present we will exit...

egrep "c_admin2" /etc/passwd > /dev/null
if [ $? -eq 0 ] ; then
   echo "User exists"
   exit 4
fi

## Add the group s_ppm ....

groupadd -g 70022 s_ppm > /dev/null 2> /dev/null
if [ $? -eq 0 ] ; then
   echo "Group added successfully..."
else
   echo "Error: Group add  failed..."
   exit 6
fi

## Add the group c_ppm ....

groupadd -g 71022 c_ppm > /dev/null 2> /dev/null
if [ $? -eq 0 ] ; then
   echo "Group added successfully..."
else
   echo "Error: Group add  failed..."
   exit 6
fi


### PPM account user creation ###

## Add the PPM service account

PASS='S&9injL&2K*aMz4puA#8xwB&dvH7n0'

useradd -u 70023 -g s_ppm -s /bin/sh -c " Hitachi PPM Service Account" -p ${PASS} -d /home/s_psadmin -m s_psadmin > /dev/null 2> /dev/null

if [ $? -eq 0 ] ; then
   chage -M 99999 s_psadmin
   echo "User added sucessfuly..."
else
   echo "Error: User add  failed..."
   exit 7
fi

## Add the PPM managed admin account

PASS='$1$rXAL3CFW$MtaI6uWpmp.tBdguFIJrt/'

useradd -u 71023 -g c_ppm -s /bin/sh -c "Hitachi PPM  Managed Admin account" -p ${PASS} -d /home/c_admin1 -m c_admin1 > /dev/null 2> /dev/null

## Add the PPM managed admin account

PASS='$1$rXAL3CFW$MtaI6uWpmp.tBdguFIJrt/'

useradd -u 71024 -g c_ppm -s /bin/sh -c "Hitachi PPM  Managed Admin account" -p ${PASS} -d /home/c_admin2 -m c_admin2 > /dev/null 2> /dev/null


	
## Adding the entries in sudo file for granting and restricting access to the above accounts created ##

find /etc -name sudoers

if [ $? -eq 0 ] ; then
  
   echo "#=================================================================#" >> /etc/sudoers
   echo "#Hitachi PPM Configuration " >> /etc/sudoers
   echo "Cmnd_Alias PASSWD1=/usr/bin/passwd c_admin1" >> /etc/sudoers
   echo "Cmnd_Alias PASSWD2=/usr/bin/passwd c_admin2" >> /etc/sudoers
   echo "###"
   echo "#Restricting users in group s_ppm to run only the above commands" >> /etc/sudoers
   echo "%s_ppm       ALL= NOPASSWD: PASSWD1, PASSWD2" >> /etc/sudoers
   echo "###"
     echo "#Granting users under c_ppm with root access" >> /etc/sudoers
   echo "%c_ppm       ALL=(ALL)    NOPASSWD:   ALL" >> /etc/sudoers
   echo "#=================================================================#" >> /etc/sudoers
	
else
   echo "File doesn't exists..."
   exit 7
fi

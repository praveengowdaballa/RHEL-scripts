#!/bin/bash

#Title:MSS_RHEL-6_set_NTP_servers.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

################## Export PATH #############################

path

##################### Define Variable Here #################
CONFIG_FILE="/etc/ntp.conf"
num_fields=2
ntp_servers=""
typeset -i status=0
typeset -i change=0

ntp_servers="`get_user_input NTP_SERVERS`"
if [ -z "$ntp_servers" ]
then
        cecho "Primary and Secondary NTP servers must be set.  Aborting..." red
        cecho "You must now manually set your ntp servers in /etc/ntp.conf file" red
        exit 1
fi

tmpfile=""
save="no"
if [ -f $CONFIG_FILE ]
then
	egrep 'server [012].rhel|OUR TIMESERVERS' $CONFIG_FILE > /dev/null
	if [ $? = 0 ]
	then
		tmpfile="/tmp/.tmp.`timestamp`"
		# Delete pre-define NTP servers.  Also delete reference to 'OUR TIMESERVERS'
		sed -e '/server [012].rhel/d; /OUR TIMESERVERS/d' $CONFIG_FILE > $tmpfile
		if [ $? = 0 ]
		then
			mv $tmpfile $CONFIG_FILE
		else 
			exit 1
		fi
	fi

	# Remove any ntp servers in /etc/ntp.conf that aren't suppose to be there
	# generate a list of servers that should be in there
	GREP_OPT="-v"
	for ntp_server in $ntp_servers
	do
		GREP_OPT="$GREP_OPT -e $ntp_server"
	done

	typeset -i str_pos=0
	# Comment out any server reference entry that does not match the expected NTP servers
	for str_pos in `cat /etc/ntp.conf | grep -w ^"server" -n | grep $GREP_OPT | awk -F: '{print $1}'`
	do	
		if [ ! -z "$str_pos" ]
		then
			if [ "$save" != "yes" ]
			then
        			backup_file="$CONFIG_FILE.`timestamp`"
        			rc=`copy_config_file $CONFIG_FILE $backup_file`
				if [ $rc -ne 0 ]
				then
				echo "Backup operation failed ...$CONFIG_FILE"
					exit 1

				else
					save="yes"
				fi
			fi
        		tmpfile="/tmp/.tmp.`timestamp`"
			cat $CONFIG_FILE | sed ''$str_pos's/^server \(.*\)/#server \1 /' > $tmpfile
			if [ $? = 0 ]
			then
				mv $tmpfile /etc/ntp.conf
			fi

			if [ $? = 0 ]
			then
				change=1
			fi
		fi
	done

	# include the NTP servers if they don't already exist in /etc/ntp.conf file
	for ntp_server in $ntp_servers
	do
		grep -w $ntp_server $CONFIG_FILE > /dev/null
		if [ $? != 0 ]
		then
			if [ "$save" != "yes" ]
			then
        			backup_file="$CONFIG_FILE.`timestamp`"
        			rc=`copy_config_file $CONFIG_FILE $backup_file`
				if [ $rc -ne 0 ]
				then
					exit 1
				else
					save="yes"
				fi
			fi
			echo "server $ntp_server" >> $CONFIG_FILE
			cecho "server $ntp_server added into $CONFIG_FILE" yellow
			change=1
		else
		
			cecho "server $ntp_server is already present in $CONFIG_FILE" green

		fi
		

	done

	
fi
#This is added as part of security hardening CIS-3.6 date:5-Mar-15

if grep --silent "^restrict default" $CONFIG_FILE; then
sed -i '/^restrict default/c restrict default kod nomodify notrap nopeer noquery' $CONFIG_FILE
else
sed -i '9 i restrict default kod nomodify notrap nopeer noquery' $CONFIG_FILE
fi

if grep --silent "^restrict -6 default" $CONFIG_FILE; then
sed -i '/^restrict -6 default/c restrict -6 default kod nomodify notrap nopeer noquery' $CONFIG_FILE
else
sed -i '/^restrict default/a restrict -6 default kod nomodify notrap nopeer noquery' $CONFIG_FILE
fi

ntpd_file="/etc/sysconfig/ntpd"
if grep --silent -i "^options" $ntpd_file; then
sed -i '/^OPTIONS/c OPTIONS="-u ntp:ntp"' $ntpd_file
else
sed -i '2 i OPTIONS="-u ntp:ntp"' $ntpd_file
fi

# Restart ntp if a change has been made.
if [ $change -eq 1 ]
then
				
		systemctl is-enabled ntpd.service > /dev/null
		if [ $? != 0 ]
                then
		cecho "ntpd.service is disabled... enabling" yellow
		systemctl enable ntpd.service
		fi

		systemctl is-active ntpd.service > /dev/null
		if [ $? != 0 ]
		then
		cecho "ntpd.service is stopped...Staring" yellow 
		systemctl start ntpd.service
		else
		cecho "restarting ntpd.service service..." yellow
		systemctl restart ntpd.service
		fi
fi

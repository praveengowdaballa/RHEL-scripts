#!/bin/bash

#Title:MSS_RHEL-6_SNMP.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path

####################### Define Variable Here #################

# Checking of HOSTNAME and setting the password as per the Datacenter Name

DC_NAME=`echo ${HOSTNAME} | awk '{ print substr($0 ,4 ,2) }'`

case ${DC_NAME} in
 [Pp][Gg])
PASS='drAFrac5etu82eF7crUgUd?eKacha3';;

 [Pp][Cc])
PASS='pHEKa5aMahaD5UWruGeRe&3haphupr';;

 [Bb][Ss])
PASS='th=*rupreBret&e9Atawr7c-5kebas';;

 [Lll[Uu])
PASS='S&eprutrumAM9stasTEJaPhufAxAWu';;

 [Mm][Aa])
PASS='=atr$+&FUbR_g@drudrucRudraB-W#';;

 [Aa][Cc])
PASS='gaken7zUrAM@b#Aha!UTRubruyEtHa';;

 [Ff][Rr])
PASS='_e@wurap#efE9hestuwR6predrut2$';;

 [Ww][Ii])
PASS='zuB$peM5c7TH=wrUQ3VeR3g?5*&8ru';;

 [Ll][Aa])
PASS='drUve6RE$uN$KaswAcr5TaNAm6Y*c=';;

 [Ll][Ii])
PASS='jadr5=2e83c@+ZacuThEvUyU9$r6st';;

 [Ss][Pp])
PASS='*r_ne@W2n$hEXErUn*_AWubre3u9A#';;

 [Nn][Ss])
PASS='dr+jagaDreCrAracRac#akEpHUnU*p';;

 [Zz][Bb])
PASS='fRU+ejuF$a=ubu8AhE2pa_aSwe!3';;

*)
 cecho "${HOSTNAME} may not be as per COLT's naming standards.Please set the password manually for s_monitor" yellow;;

esac

# Check permissions... exit right away....
if [ "`id -ur`" != '0' ]; then
   cecho 'Error: you must be root to proceed with SNMP configuration...' red
   exit 1
fi

## Check if its Redhat or Redhat  varient... else exit....
if [ ! -f /etc/redhat-release ]; then
   cecho 'Error: OS is not Redhat or Redhat varient...' red
   exit 2
fi


# Finally check if SNMP is installed properly on the OS
if [ ! -f /etc/snmp/snmpd.conf ]  ; then
   cecho 'Error: SNMP may not be installed properly... /etc/snmp/snmpd.conf missing ' red
   exit 5

else
	## Check if group exists.. If present we will exit...
	egrep "s_monitor" /etc/group > /dev/null
	if [ $? -eq 0 ] ; then
    	cecho "s_monitor Group exists..." green
	else
		## Add the group ....
		groupadd -g 80022 s_monitor
		if [ $? -eq 0 ] ; then
		   cecho " s_monitor Group added sucessfuly..." green
		else
		   cecho "Error: s_monitor Group add  failed..." red
		   exit 6
		fi
	fi


	## Check if user exists.. If present we will exit...
	egrep "s_monitor" /etc/passwd > /dev/null
	if [ $? -eq 0 ] ; then
	   cecho "s_monitor User exists..." green
	else

		if [ -z ${PASS} ];
		 then
		 	 cecho "Set the password for s_monitor manually" yellow
		 	 useradd -u 80023 -g s_monitor -s /bin/bash -c "COLT HP" -d /home/s_monitor -m s_monitor
		 else
			 useradd -u 80023 -g s_monitor -s /bin/bash -c "COLT HP" -p ${PASS} -d /home/s_monitor -m s_monitor
		fi

		if [ $? -eq 0 ] ; then
		   chage -M 99999 s_monitor
		   cecho "s_monitor User added sucessfuly..." green
		else
		   cecho "Error: s_monitor User add  failed..." red
		   exit 7
		fi
	fi

	# Make the snmpd.cond changes
	egrep "rocommunity Monitor" /etc/snmp/snmpd.conf > /dev/null
	if [ $? -eq 0 ]
	then
		cecho "Already Compliance with Colt Standard with Community String \" rocommunity Monitor \"... " green
	else
		
		cecho "Configuring SNMP..." green
		cecho "Adding community string \" rocommunity Monitor \" to /etc/snmp/snmpd.conf "
		mv /etc/snmp/snmpd.conf /etc/snmp/snmpd.conf.orig.`timestamp`
		echo "rocommunity Monitor" > /etc/snmp/snmpd.conf

		systemctl is-enabled snmpd.service > /dev/null
                if [ $? != 0 ]
                then
                cecho "snmpd.service is disabled... enabling.." yellow
                systemctl enable snmpd.service
                fi

                systemctl is-active snmpd.service > /dev/null
                if [ $? != 0 ]
                then
                cecho "snmpd.service is stopped...Staring" yellow
                systemctl start snmpd.service
                else
                cecho "restarting snmpd.service service..." yellow
                systemctl restart snmpd.service
                fi




		# check file permission for snmpd file.
		SNMPD_FILE="/etc/snmp/snmpd.conf"
		expected_perm="640"

		for afile in $SNMPD_FILE
		do
	        current_perm=`stat $afile -c "%a"`
        	if [ $current_perm != $expected_perm ]
	        then
                chmod $expected_perm $afile
        	fi
		done

		cecho "You can do a quick test by \"snmpwalk -c Monitor -v 2c localhost system\"" green
	fi
fi


#!/bin/bash

#Title:MSS_RHEL-7_setup_password_complexity_values.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

################## Export PATH #############################

path

##################### Define Variable Here #################
CONFIG_FILE="/etc/login.defs"
Delimeter=' '
num_fields=2

PASS_MAX_DAYS_VAL="90"
PASS_MIN_DAYS_VAL="7"
PASS_MIN_LEN_VAL="8"
PASS_WARN_AGE_VAL="8"
PASS_MAX_DAYS_VAR="PASS_MAX_DAYS"
PASS_MIN_DAYS_VAR="PASS_MIN_DAYS"
PASS_MIN_LEN_VAR="PASS_MIN_LEN"
PASS_WARN_AGE_VAR="PASS_WARN_AGE"


DATA_VAR="$PASS_MAX_DAYS_VAR"
DATA_VAL="$PASS_MAX_DAYS_VAL"
DELIMITER=' '

# Check and make PASS_MAX_DAYS is compliant, if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="$PASS_MIN_DAYS_VAR"
DATA_VAL="$PASS_MIN_DAYS_VAL"

# Check and make PASS_MIN_DAYS is compliant, if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="$PASS_MIN_LEN_VAR"
DATA_VAL="$PASS_MIN_LEN_VAL"
DELIMITER=' '

#set -x
# Check and make PASS_MIN_LEN is compliant, if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="$PASS_WARN_AGE_VAR"
DATA_VAL="$PASS_WARN_AGE_VAL"
DELIMITER=' '

# Check and make PASS_WARN_AGE is compliant, if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


CONFIG_FILE="/etc/security/pwquality.conf"
Delimeter=' = '
num_fields=2

MINLEN_VAR="minlen"
DCREDIT_VAR="dcredit"
UCREDIT_VAR="ucredit"
LCREDIT_VAR="lcredit"
#OCREDIT_VAR="ocredit"

MINLEN_VAL="8"
DCREDIT_VAL="1"
UCREDIT_VAL="1"
LCREDIT_VAL="1"
#OCREDIT_VAL="1"


DATA_VAR="$MINLEN_VAR"
DATA_VAL="$MINLEN_VAL"
DELIMITER=" = "

# Check and make MINLEN is compliant, if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' = ' $num_fields "yes" "yes"


DATA_VAR="$DCREDIT_VAR"
DATA_VAL="$DCREDIT_VAL"
DELIMITER=" = "

# Check and make DCREDIT is compliant, if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' = ' $num_fields "yes" "yes"

DATA_VAR="$UCREDIT_VAR"
DATA_VAL="$UCREDIT_VAL"
DELIMITER=' = '

# Check and make UCREDIT is compliant, if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' = ' $num_fields "yes" "yes"

DATA_VAR="$LCREDIT_VAR"
DATA_VAL="$LCREDIT_VAL"
DELIMITER=' = '

# Check and make LCREDIT is compliant, if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' = ' $num_fields "yes" "yes"


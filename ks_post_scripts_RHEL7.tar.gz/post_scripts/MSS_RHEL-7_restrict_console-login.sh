#!/bin/bash 
#Title: MSS_RHEL-7_restrict_console-login.sh
#Author:saravana.kannayan@colt.net
#Version:1.0


#####################Environment PATH ####################################

export PATH=$PATH:/bin:/usr/bin:/sbin:/usr/local:/usr/local/sbin

######################## Include Functions ############################

. functions.sh

###############################################################


### Define Variable Here ###############

CONFIG_FILE=/etc/systemd/logind.conf
DATA_VAR=NautoVTs
DATA_VAL="3"
DELIMITER='='
num_fields=2

make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL $DELIMITER $num_fields "yes" "yes"




#!/bin/bash

#Title:MSS_RHEL-6_set_system_locale.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path

####################### Define Variable Here #################

CONFIG_FILE="/etc/locale.conf"

#  Get custom attribues
KEYTABLE_VAL=`get_user_input "KEYTABLE"`
if [ -z $KEYTABLE_VAL ]
then
        cecho "$0: KEYTABLE not set." red
	KEYTABLE_VAL=en_GB.utf8
fi


KEYMAP_VAL=`get_user_input "KEYMAP"`
if [ -z $KEYMAP_VAL ]
then
        cecho "$0: KEYMAP not set." red
        KEYMAP_VAL=uk
fi

current_keytable=`localectl status | grep -w "System Locale"|awk -F"=" '{print $2}'`
if [ $KEYTABLE_VAL = $current_keytable ]
then
	cecho "Already Compliance with Standard... Currently the following System Locale set on this system $current_keytable" green
else
	/usr/bin/localectl set-locale LANG=$KEYTABLE_VAL
	if [ $? -eq 0 ];then
	cecho "System Locale setting changed to $KEYTABLE_VAL" yellow
	else
	cecho "Failed to change System Locale $KEYTABLE_VAL" red
	fi
fi

current_keymap=`localectl status | grep -w "VC Keymap"|awk -F": " '{print $2}'`
if [ $KEYMAP_VAL = $current_keymap ]
	then
	cecho "Already Compliance with Colt Standard...System Keyboard Layout is set to $current_keymap" green
else
	/usr/bin/localectl set-keymap $KEYMAP_VAL
	if [ $? -eq 0 ];then
	cecho "System Keyboard setting changed to $KEYMAP_VAL" yellow
	else
	cecho "Failed to change System Locale to $KEYMAP_VAL" red
	fi
fi


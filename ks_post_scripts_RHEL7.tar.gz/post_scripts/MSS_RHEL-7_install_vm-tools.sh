#!/bin/bash
#Purpose:Script will install VMware Tools in Virtual Machines
#Author: Saravana.kannayan@colt.net

#Export PATH variable
export PATH=$PATH:/bin:/usr/bin:/sbin:/usr/local:/usr/local/sbin

VM_Local_DIR="/ColtExtras/"

VM_DIR="ColtExtras_RHEL7"

VM_Tools="VMwareTools-9.4.10-2068191.tar.gz"

# Get software server IP and root directory

if [ -f  $VM_Local_DIR/$VM_Tools  ]
then
        cd $VM_Local_DIR
        /bin/tar -xvzf $VM_Tools
        if [ $? -eq 0 ];then echo "Extracting $VM_Tools successfull...";fi
        ./vmware-tools-distrib/vmware-install.pl -d
        if [ $? -eq 0 ];then echo "Installation of vmtools Successfull...";fi

else
prov_server=`get_user_input prov_server`
if [ -z "$prov_server" ]
then
        cecho "prov_server not set in defaults.cfg.  Aborting..." red
        cecho "You must now manually install vmtools..." red
        exit 1
fi
cd /ColtExtras/
/usr/bin/wget ftp://$prov_server/$VM_DIR/$VM_Tools
if [ $? -eq 0 ];then echo "Downloading $VM_Tools successfull...";fi
        /bin/tar -xvzf $VM_Tools
       if [ $? -eq 0 ];then echo "Extracting $VM_Tools successfull...";fi
       ./vmware-tools-distrib/vmware-install.pl -d
        if [ $? -eq 0 ];then echo "Installation of vmtools Successfull...";fi

fi


#!/bin/bash



NB_Local_DIR="/ColtExtras"

NB_Client="SYMCnbclient_Linux-RedHat2.6.18_7.6.0.3.tar"

# Get software server IP and root directory

if [ -f  $NB_Local_DIR/$NB_Client  ]
then
        cd $NB_Local_DIR
        /bin/tar -xvf $NB_Client
        if [ $? -eq 0 ];then echo "Extracting $NB_Client successfull...";fi
fi


/usr/bin/expect  << EOD

set timeout 10

cd /ColtExtras/SYMCnbclient_Linux-RedHat2.6.18_7.6.0.3

spawn "./install"

expect "Do you wish to continue?"
send "y\r";

expect "Do you want to install the NetBackup client software for this client?"
send "y\r"

expect "Enter the name of the NetBackup master server :"
send "XX.XX.XX.XX\r"

expect "name of the NetBackup client?"
send "y\r"

interact
EOD


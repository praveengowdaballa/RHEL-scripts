#!/bin/bash

#Title:MSS_RHEL-7_disable_ipv6.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path


####################### Define Variable Here #################

    CONFIG_FILE="/etc/sysctl.d/disable-ipv6.conf"
    DATA_VAR="net.ipv6.conf.all.disable_ipv6"
    DATA_VAL="1"
    DELIMITER=' = '
    num_fields=2

#if [ ! -f /etc/modprobe.d/ipv6.conf ]
#       then
#       touch /etc/modprobe.d/ipv6.conf
#       fi
    
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL $DELIMITER $num_fields "yes" "yes"

sysctl -p $CONFIG_FILE

	

#!/bin/bash

#Title:MSS_RHEL-7_Config-security-remediation.sh
#Author:saravana.kannayan@colt.net
#Version:1.0
#Notes: This script will have the remediation for security checks
############################################################

. functions.sh

#####################Export PATH #############################

path


####################### Define Variable Here #################


# Set Daemon umask
CONFIG_FILE="/etc/sysconfig/init"
exp_val="027"
if grep --silent ^umask $CONFIG_FILE;then

	val=`grep "umask 027" $CONFIG_FILE |awk '{print $2}'`

	if [ $val -ne $exp_val ];
	then 
		cecho "Updating $CONFIG_FILE with umask 027..." yellow
		sed -i 's/^umask.*/umask 027/g' $CONFIG_FILE
	else
		cecho "Daemon Umask value already set as \"027\" Compliance with Colt Standard" green
	fi
else
cecho "Updating $CONFIG_FILE with umask 027..." yellow
echo "" >> $CONFIG_FILE
echo "#Set Daemon umask as per Colt security Compliance" >> $CONFIG_FILE
echo "umask 027" >> $CONFIG_FILE
fi

#Upgrade Password Hashing Algorithm to SHA-512

#authconfig --test | grep hashing | grep sha512 > /dev/null
#
#if [ $? -eq 1 ]
#then
#cecho "Updating Password Hashing Algorithm to SHA-512" yellow
#authconfig --passalgo=sha512 --update
#	if [ $? -eq 0 ]
#	then
#	cecho "Updated Password Hashing Algorithm to SHA-512 sucessfully " green
#	else
#	cecho " Failed to update,Please check manually" red
#	fi
#else
#cecho "Already Compliance with Colt Standard, Password Hashing Algorithm is SHA-512" green
#fi

#6.3.1 CIS Set Password Hashing Algorithm to SHA-512


#sysauth=`grep -q "^password.*sufficient.*pam_unix.so.*sha512" /etc/pam.d/system-auth`
sysauth=`if grep -q "^password.*sufficient.*pam_unix.so.*sha512" /etc/pam.d/system-auth;then echo "yes";else echo "no";fi`
passauth=`if grep -q "^password.*sufficient.*pam_unix.so.*sha512" /etc/pam.d/password-auth;then echo "yes";else echo "no";fi`

if [ $sysauth = "no" -a $passauth = "no" ]; then

#if ! grep -q "^password.*sufficient.*pam_unix.so.*sha512" /etc/pam.d/system-auth; then
        cecho "Updating Password Hashing Algorithm to SHA-512" yellow
        sed -i --follow-symlink "/^password.*sufficient.*pam_unix.so/ s/md5/sha512/" /etc/pam.d/system-auth
        sed -i --follow-symlink "/^password.*sufficient.*pam_unix.so/ s/md5/sha512/" /etc/pam.d/password-auth
        if [ $? -eq 0 ]
       then
       cecho "Updated Password Hashing Algorithm to SHA-512 sucessfully " green
       else
       cecho " Failed to update,Please check manually" red
       fi
elif [ $sysauth = "no" -a $passauth = "yes" ]; then
 cecho "Updating Password Hashing Algorithm to SHA-512" yellow
 sed -i --follow-symlink "/^password.*sufficient.*pam_unix.so/ s/md5/sha512/" /etc/pam.d/system-auth
 if [ $? -eq 0 ]
       then
       cecho "Updated Password Hashing Algorithm to SHA-512 sucessfully " green
       else
       cecho " Failed to update,Please check manually" red
       fi
elif [ $sysauth = "yes" -a $passauth = "no" ]; then
 cecho "Updating Password Hashing Algorithm to SHA-512" yellow
 sed -i --follow-symlink "/^password.*sufficient.*pam_unix.so/ s/md5/sha512/" /etc/pam.d/password-auth
 if [ $? -eq 0 ]
       then
       cecho "Updated Password Hashing Algorithm to SHA-512 sucessfully " green
       else
       cecho " Failed to update,Please check manually" red
       fi
else
        cecho "Already Compliance with Colt Standard, Password Hashing Algorithm is SHA-512" green
fi


encryptmethod=`if grep -q "^ENCRYPT_METHOD MD5" /etc/login.defs;then echo "yes";else echo "no";fi`
md5enab=`if grep -q "^MD5_CRYPT_ENAB yes" /etc/login.defs;then echo "yes";else echo "no";fi`

if [ $encryptmethod = "yes" -a $md5enab = "yes" ]; then

#if grep --silent "^ENCRYPT_METHOD MD5" /etc/login.defs ; then
        cecho "Updating ENCRYPT_METHOD to SHA512 and MD5_CRYPT_ENAB/ to no" yellow
        sed -i "/^ENCRYPT_METHOD/ s/MD5/SHA512/g" /etc/login.defs
        sed -i "/^MD5_CRYPT_ENAB/ s/yes/no/g" /etc/login.defs
        if [ $? -eq 0 ]
       then
       cecho "Updated Password Hashing Algorithm to SHA-512 sucessfully " green
       else
       cecho " Failed to update,Please check manually" red
       fi

elif [ $encryptmethod = "yes" -a $md5enab = "no" ]; then
         cecho "Updating ENCRYPT_METHOD to SHA512" yellow
         sed -i "/^ENCRYPT_METHOD/ s/MD5/SHA512/g" /etc/login.defs
         if [ $? -eq 0 ]
       then
       cecho "Updated Password Hashing Algorithm to SHA-512 sucessfully " green
       else
       cecho " Failed to update,Please check manually" red
       fi

elif [ $encryptmethod = "no" -a $md5enab = "yes" ]; then
        cecho "Updating MD5_CRYPT_ENAB to no" yellow
         sed -i "/^MD5_CRYPT_ENAB/ s/yes/no/g" /etc/login.defs
        if [ $? -eq 0 ]
       then
       cecho "Updated MD5_CRYPT_ENAB to \"no\" sucessfully " green
       else
       cecho "Failed to update,Please check manually" red
       fi
else
        cecho "Already Compliance with Colt Standard, Password Hashing Algorithm is SHA-512 and MD5_CRYPT_ENAB to no" green
fi


#7.4 Set Default umask for Users

CONFIG_FILE="/etc/bashrc"
exp_val="077"
if grep --silent ^umask $CONFIG_FILE;then

        val=`grep "umask $exp_val" $CONFIG_FILE |awk '{print $2}'`

        if [ $val -ne $exp_val ];
        then
                cecho "Updating $CONFIG_FILE with umask $exp_val ..." yellow
                sed -i 's/^umask.*/umask '$exp_val'/g' $CONFIG_FILE
        else
                cecho "Daemon Umask value already set as \"$exp_val\" Compliance with Colt Standard" green
        fi
else
cecho "Updating $CONFIG_FILE with umask $exp_val ..." yellow
echo "" >> $CONFIG_FILE
echo "#Set umask as per Colt security Compliance" >> $CONFIG_FILE
echo "umask $exp_val" >> $CONFIG_FILE
fi

#7.5 Lock Inactive User Accounts

CONFIG_FILE="/etc/default/useradd"
if ! grep -q "^INACTIVE=35" $CONFIG_FILE; then
cecho "Updating Lock Inactive User Accounts to 35 days"
sed -i "/^INACTIVE.*/ s/INACTIVE.*/INACTIVE=35/" $CONFIG_FILE
if [ $? -eq 0 ]
       then
       cecho "Updated $CONFIG_FILE with INACTIVE=35 sucessfully " green
       else
       cecho " Failed to update,Please check manually" red
       fi
else
        cecho "Already Compliance with Colt Standard, Lock Inactive=35 " green
fi

 
#9.2.12 User Home directory creation

mkdir /var/ftp
mkdir /var/run/avahi-daemon
mkdir /var/lib/avahi-autoipd


#CIS 5.3 Configure logrotate - /var/log/boot.log

sed -i.bak '2 a/var/log/boot.log' /etc/logrotate.d/syslog


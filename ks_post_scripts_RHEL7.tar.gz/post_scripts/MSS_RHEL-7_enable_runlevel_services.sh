#!/bin/bash

#Title:MSS_RHEL-7_enable_runlevel_services.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path

####################### Define Variable Here #################
common_services="chronyd.service psacct.service sysstat.service auditd.service"

switch_on_common_services "$common_services"

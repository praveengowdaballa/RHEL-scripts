#!/bin/bash

#Title:MSS_RHEL-6_check_root_password.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path

####################### Define Variable Here #################


ROOT_USER_PASSWORD=`get_user_input RH_ROOT_PASSWORD`
if [ -z "$ROOT_USER_PASSWORD" ]
then
	ROOT_USER_PASSWORD="changen0w"
fi
	

ROOT_USER_LOGIN=`get_user_input RH_USER_LOGIN`
if [ -z "$ROOT_USER_LOGIN" ]
then
	ROOT_USER_LOGIN="root"
fi

if [ ! -f chkpwd ] 
then
	cecho "chkpwd not found." red
	echo "exiting....."
	exit 1
fi

echo $ROOT_USER_PASSWORD | ./chkpwd $ROOT_USER_LOGIN
if [ $? = 0 ]
then
	cecho "Enforcing immediate password change for user $ROOT_USER_LOGIN." yellow
	chage -d 0 $ROOT_USER_LOGIN
	if [ $? != 0 ]
	then
		exit 1
	cecho "Enforcing immediate password change failed" red 
	fi	
fi

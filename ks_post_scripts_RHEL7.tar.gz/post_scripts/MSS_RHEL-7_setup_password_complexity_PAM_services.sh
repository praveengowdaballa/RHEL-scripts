#!/bin/bash

#Title:MSS_RHEL-7_setup_password_complexity_PAM_services.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

create_file_rhel7()
{

cat <<! > $CONFIG_FILE
#%PAM-1.0
# This file is auto-generated.
# User changes will be destroyed the next time authconfig is run.
auth        required      pam_env.so
auth        required      pam_tally2.so deny=2 onerr=fail unlock_time=600
auth        sufficient    pam_unix.so nullok try_first_pass
auth        requisite     pam_succeed_if.so uid >= 1000 quiet_success
auth        required      pam_deny.so

account     required      pam_tally2.so
account     required      pam_unix.so
account     sufficient    pam_localuser.so
account     sufficient    pam_succeed_if.so uid < 1000 quiet
account     required      pam_permit.so

password    required     pam_pwquality.so try_first_pass local_users_only retry=3 authtok_type= minlen=8 lcredit=-1 ucredit=-1 dcredit=-1 ocredit=-1
password    sufficient    pam_unix.so md5 shadow nullok try_first_pass use_authtok remember=20
password    required      pam_deny.so

session     optional      pam_keyinit.so revoke
session     required      pam_limits.so
-session     optional      pam_systemd.so
session     [success=1 default=ignore] pam_succeed_if.so service in crond quiet use_uid
session     required      pam_unix.so
!
chmod 644 $CONFIG_FILE
}



#####################Export PATH #############################

path


####################### Define Variable Here #################
CONFIG_FILE1="/etc/pam.d/system-auth"
CONFIG_FILE2="/etc/pam.d/password-auth"
BACKUP_FILE=""
TEMP_FILE=""
typeset -i exitcode=0
OSFILE="/etc/redhat-release"



num_fields=2
typeset -i status=0

val=`os_version`


#Create  /etc/security/access-cron.conf, if necessary.  Stops crond from complaining
if [ ! -f /etc/security/access-cron.conf ]
then
	touch /etc/security/access-cron.conf
	if [ $? != 0 ]
	then
		cecho "Cannot create /etc/security/access-cron.conf file " red
		echo
		echo "exiting...."
		exi t 1
	else
		cecho "/etc/security/access-cron.conf created." yellow
		echo
	fi
else
	cecho "/etc/security/access-cron.conf already exist." green
	echo
fi

if [ ! -f $CONFIG_FILE1 ]
then	
	$CONFIG_FILE="$CONFIG_FILE1"
	if [ "$val" = "7" ]
	then
               create_file_rhel7
	       cecho "$CONFIG_FILE is not present...hence it's created "
	fi
fi

if [ ! -f $CONFIG_FILE2 ]
then
	$CONFIG_FILE="$CONFIG_FILE2"
        if [ "$val" = "7" ]
        then
               create_file_rhel7
               cecho "$CONFIG_FILE2 is not present...hence it's created "
        fi
fi



if [ "$val" = "7" ]
then
	DATA_LINE="auth        required      pam_tally2.so deny=5 onerr=fail unlock_time=600"
	search_line="auth.*required.*pam_tally2.so"
	line_marker="auth.*sufficient.*nullok"
	check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "deny=5"
	check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "onerr=fail"
	check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "unlock_time=600"
	check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "deny=5"
	check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "onerr=fail"
	check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "unlock_time=600"

        DATA_LINE="account     required      pam_tally2.so"
        search_line="account.*required.*pam_tally2.so"
        line_marker="account.*required.*pam_unix.so"
        check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "pam_tally2.so"
        check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "pam_tally2.so"
	
	if grep -q "^password.*requisite.*pam_pwquality.so.*" /etc/pam.d/system-auth; then
        cecho "Updating \"Password requisite\" to \" password required \"  in /etc/pam.d/system-auth" yellow
        sed -i --follow-symlink "/^password.*requisite.*pam_pwquality.so.*/ s/requisite/required/" /etc/pam.d/system-auth
        sed -i --follow-symlink "/^password.*requisite.*pam_pwquality.so.*/ s/requisite/required/" /etc/pam.d/password-auth
        if [ $? -eq 0 ]
       then
       cecho "Updated Password required sucessfully in both system-auth and password-auth" green
       else
       cecho " Failed to update,Please check manually" red
       fi

	else
        cecho "Already Compliance with Colt Standard" green
	fi


        DATA_LINE="password    required     pam_pwquality.so try_first_pass retry=3 minlen=8 lcredit=-1 ucredit=-1 dcredit=-1 ocredit=-1"
        search_line="password.*required.*pam_pwquality.so"
        line_marker="password.*sufficient.*pam_unix.so"
        check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "retry=3"
        check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "minlen=8"
        check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "lcredit=-1"
        check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "ucredit=-1"
        check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "dcredit=-1"
        check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "ocredit=-1"
        check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "retry=3"
        check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "minlen=8"
        check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "lcredit=-1"
        check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "ucredit=-1"
        check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "dcredit=-1"
        check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "ocredit=-1"

        DATA_LINE="password    sufficient    pam_unix.so md5 shadow nullok try_first_pass use_authtok remember=20"
        search_line="password.*sufficient.*pam_unix.so"
        line_marker="password.*required.*pam_deny.so"
        check_file $CONFIG_FILE1 "$search_line" "$line_marker" "$DATA_LINE" "remember=20"
        check_file $CONFIG_FILE2 "$search_line" "$line_marker" "$DATA_LINE" "remember=20"

        # For cron
		
        CONFIG_FILE="/etc/pam.d/crond"
        DATA_LINE="account    required   pam_listfile.so onerr=succeed item=user sense=allow file=/etc/security/access-cron.conf"
        search_line="account.*required.*pam_listfile.so"
        line_marker="account.*include.*password-auth"
        check_file $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "file=/etc/security/access-cron.conf"

	DATA_LINE="account    sufficient pam_succeed_if.so use_uid quiet uid = 0"
	search_line="account.*sufficient.*pam_succeed_if.so"
	line_marker="account.*required.*pam_listfile.so"
	check_file $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "use_uid"
	check_file $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "quiet"

        # For sshd
        CONFIG_FILE="/etc/pam.d/sshd"
        DATA_LINE="account    required     pam_access.so"
        search_line="account.*required.*pam_access.so"
        line_marker="account.*required.*pam_nologin.so"
        check_file $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "pam_access.so"

	# Passwd PAM pwquality setting
	CONFIG_FILE="/etc/pam.d/passwd"
	DATA_LINE="password   required     pam_pwquality.so retry=3"
	search_line="password.*required.*pam_pwquality.so"
	line_marker="password.*substack.*system-auth"
	check_file $CONFIG_FILE "$search_line" "$line_marker" "$DATA_LINE" "retry=3"


fi	

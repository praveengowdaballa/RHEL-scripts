#!/bin/bash

#Title:MSS_RHEL-6_enable_runlevel_services.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path

####################### Define Variable Here #################
common_services="abrt-ccpp.service abrt-oops.service abrt-vmcore.service abrt-xorg.service abrtd.service atd.service smartd.service avahi-daemon.service mdmonitor.service xinetd"
	

	RH_DISABLE_SERVICES=`get_user_input RH_DISABLE_SERVICES`
	if [ ! -z "$RH_DISABLE_SERVICES" ]
	then
		cecho "RH_DISABLE_SERVICES not set.. Using defaults..." yellow
		common_services="$RH_DISABLE_SERVICES"
	fi

switch_off_common_services "$common_services"

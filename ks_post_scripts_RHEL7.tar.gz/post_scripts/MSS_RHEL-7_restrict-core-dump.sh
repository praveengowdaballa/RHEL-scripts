#!/bin/bash

#Title:MSS_RHEL-7_disable_ipv6.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path


####################### Define Variable Here #################
#Disable Restrict Core dump
CONFIG_FILE="/etc/sysctl.conf"
typeset -i num_fields=2
typeset -i exitcode=0
typeset -i status=0

core_dumps="0"
DATA_VAR="fs.suid_dumpable"
DATA_VAL="$core_dumps"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"


#Core dump limit
    CONFIG_FILE="/etc/security/limits.conf"
    DATA_VAR="* hard core 0"
	
	grep "* hard core" /etc/security/limits.conf > /dev/null
 
    if [ $? -eq 1 ]
	then
		cecho "Updating $CONFIG_FILE" yellow
		sed -i.bak '$ i\'"$DATA_VAR"'' $CONFIG_FILE
	else 
		cecho "Already Compliance with Colt standard." green
    fi
	

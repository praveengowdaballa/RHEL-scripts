#!/bin/bash
#Title:MSS_RHEL-7_Set_default-runlevel.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path


####################### Define Variable Here #################



check1=`systemctl get-default`
        if [ $check1 = "graphical.target"  ]
                then
                cecho "default target is not set to multiuser.target....Setting multi-user.target as a default runlevel" yellow
                systemctl set-default multi-user.target
                rc=`echo $?`
                         if [ $rc = 0 ]
                                 then
                                 cecho "multi-user.target is set as default runlevel. Compliance with Colt Standard" green
                                 else
                                         cecho "Unable to mask ctrl-alt-del target, Have a look manually" red
                         fi

                else
                        cecho "multi-user.target is already set as default runlevel. Compliance with Colt Standard" green
        fi


#!/bin/bash 

#Title:MSS_RHEL-7_set-banner-sshd.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path


####################### Define Variable Here #################

Configfile=/etc/issue
Tmp_banner=/tmp/issue

###################### Main Function ############# ###########


cat <<! > $Tmp_banner

                          THIS DEVICE IS PART OF A
                               PRIVATE NETWORK

               *************************************************
               * Unauthorised access or use of this equipment  *
               * is prohibited and constitutes an offence under*
               * the Computer Misuse Act 1990.                 *
               * This system is being monitored and logs will  *
               * be used as evidence in court.                 *
               * If you are not authorised to use this system, *
               * Terminate this session now!                   *
               *************************************************
!



diff --brief $Tmp_banner $Configfile >/dev/null
comp_value=$?

if [ $comp_value -eq 1 ]
then
    cecho "Content in $Configfile is different....\n Hence Applying standard...." red

    copy_config_file $Configfile $Configfile.`timestamp` > /dev/null
    
    copy_config_file $Tmp_banner $Configfile > /dev/null

    chmod 644 $Configfile

else
   cecho "Banner is already Compliance with Standard... " green
fi


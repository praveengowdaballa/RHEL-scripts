#!/bin/bash
#Title:MSS_RHEL-7_set_rsyslog_server.sh 
#Author:saravana.kannayan@colt.net
#Version:1.0

######################## Include Functions ############################

. functions.sh

#####################Environment PATH ##################################

path

############################### Define Variable Here ###################
CONFIG_FILE="/etc/rsyslog.conf"
SYSLOG_ENTRY="*.info;mail.none;local1.none;local2.none;local3.none;local4.none;local5.none;local6.none;local7.none"
SYSLOG_SERVER="coltmonXX-bl"

typeset -i num_fields=0
typeset -i i=1
typeset -i notpresent=0
typeset -i newentry=0

syslog_server=`get_user_input "MONITORING_SERVER"`
if [ -z "$syslog_server" ]
then
	cecho "MONITORING_SERVER not set." red
	syslog_server="$SYSLOG_SERVER"
fi

syslog_severity=`get_user_input "RH_SYSLOG_SEVERITY"`
if [  -z "$syslog_severity" ]
then
	cecho "RH_SYSLOG_SEVERITY not found.  Using defaults...." red
	syslog_severity="$SYSLOG_ENTRY"
fi

save="no"
curr_entry=""



#cecho "Configuring rsyslog...." green
if [ -f $CONFIG_FILE ]
then
	entry=`get_entry ${CONFIG_FILE} "$syslog_server" "yes"`
	if [ ! -z "$entry" ]
	then
		curr_entry="${entry}"	
		num_fields="`echo $syslog_severity | awk -F";" '{print NF}'`"
		num_fields=`expr $num_fields + 1`
		while [ $i -lt $num_fields ]
		do
			severity="`echo $syslog_severity | awk -F\";\" -v i=$i '{print $i}'`"
			check=`echo $entry | grep -w "$severity"`
			if [ -z "$check" ]
			then
				notpresent=1
			fi
		
			if [ "$notpresent" = 1 ]
			then
				entry="${severity};${entry}"
				notpresent=0
				newentry=1
				save="yes"
			fi	
			i=`expr $i + 1`
		done
			if [ "$notpresent" = 0 ]	
			then
			cecho "Already Compliance with Colt Standard ....$syslog_severity @$syslog_server " green
			fi
	else
		save="yes"
	fi
else
	echo "$CONFIG_FILE does not exist."
	exit 1
fi

if [ "$save" = "yes" ]
then
	copy_config_file $CONFIG_FILE $CONFIG_FILE.`timestamp`
	if [ -z "$entry" ]
	then
		NEW_ENTRY=`echo "$syslog_severity @@$syslog_server"`
                echo "$NEW_ENTRY" >> $CONFIG_FILE
		cecho "rsyslog configured with $NEW_ENTRY " yellow
	else
		NEW_ENTRY=`echo "$entry"`
		cat $CONFIG_FILE | sed 's/'"$curr_entry"'.*/'"$NEW_ENTRY"'/g' > /tmp/.tmp.syslog_conf
		if [ $? = 0 ]
		then
			mv /tmp/.tmp.syslog_conf $CONFIG_FILE
			cecho "Updated $CONFIG_FILE with $NEW_ENTRY" yellow
		fi
	fi
fi
#echo "Configuring rsyslog ....Done"


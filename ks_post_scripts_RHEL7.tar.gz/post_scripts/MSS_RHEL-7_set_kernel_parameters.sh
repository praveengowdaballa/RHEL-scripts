#!/bin/bash

#Title:MSS_RHEL-6_set_kernel_parameters.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path

####################### Define Variable Here #################



CONFIG_FILE="/etc/sysctl.conf"
typeset -i num_fields=2
typeset -i exitcode=0
typeset -i status=0

###### Kernel Values #####

tcp_syncookie=1
accept_source_route=0
accept_redirects=0
rp_filter=1
syn_backlog=4096
secure_redirects=0
send_redirects=0


typeset -i status=0

#Enable TCP SYN Cookie Protection
DATA_VAR="net.ipv4.tcp_syncookies"
DATA_VAL="$tcp_syncookie"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Disable IP Forward
DATA_VAR="net.ipv4.ip_forward"
DATA_VAL="0"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Disable IP Routing
DATA_VAR="net.ipv4.conf.all.accept_source_route"
DATA_VAL="$accept_source_route"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

DATA_VAR="net.ipv4.conf.default.accept_source_route"
DATA_VAL="$accept_source_route"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Disable ICMP redirect acceptance
DATA_VAR="net.ipv4.conf.all.accept_redirects"
DATA_VAL="$accept_redirects"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

DATA_VAR="net.ipv4.conf.default.accept_redirects"
DATA_VAL="$accept_redirects"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

DATA_VAR="net.ipv6.conf.all.accept_redirects"
DATA_VAL="$accept_redirects"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

DATA_VAR="net.ipv6.conf.default.accept_redirects"
DATA_VAL="$accept_redirects"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Enable IP Spoofing Protecttion
DATA_VAR="net.ipv4.conf.all.rp_filter"
DATA_VAL="$rp_filter"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Increase Syn Backlog connections
DATA_VAR="net.ipv4.tcp_max_syn_backlog"
DATA_VAL="$syn_backlog"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

# Allow redirect from local Routers
DATA_VAR="net.ipv4.conf.all.secure_redirects"
DATA_VAL="$secure_redirects"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

DATA_VAR="net.ipv4.conf.default.secure_redirects"
DATA_VAL="$secure_redirects"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Disable Dedicated Router capability
DATA_VAR="net.ipv4.conf.all.send_redirects"
DATA_VAL="$send_redirects"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

DATA_VAR="net.ipv4.conf.default.send_redirects"
DATA_VAL="$send_redirects"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Enable Randomized Virtual Memory Region Placement
DATA_VAR="kernel.randomize_va_space"
DATA_VAL="2"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Log suspecisous packets
DATA_VAR="net.ipv4.conf.default.log_martians"
DATA_VAL="1"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Log suspecisous packets 
DATA_VAR="net.ipv4.conf.all.log_martians"
DATA_VAL="1"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Enable Ignore Broadcast Requests
DATA_VAR="net.ipv4.icmp_echo_ignore_broadcasts"
DATA_VAL="1"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Enable Bad Error Message Protection
DATA_VAR="net.ipv4.icmp_ignore_bogus_error_responses"
DATA_VAL="1"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Disable IPv6 Router Advertisements - all
DATA_VAR="net.ipv6.conf.default.accept_ra"
DATA_VAL="0"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Disable IPv6 Router Advertisements - all
DATA_VAR="net.ipv6.conf.all.accept_ra"
DATA_VAL="0"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

#Disable IPv6 
DATA_VAR="net.ipv6.conf.all.disable_ipv6"
DATA_VAL="1"
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

if [ $? -eq 0 ]
then 
	cecho "Reloading kernel parameter for change to take effect - cmd: sysctl -q -p" yellow
	sysctl -q -p
fi
exit 0

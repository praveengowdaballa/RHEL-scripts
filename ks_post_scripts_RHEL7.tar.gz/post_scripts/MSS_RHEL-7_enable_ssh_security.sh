#!/bin/bash 
#Title: MSS_RHEL-7_restrict_console-login.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

######################## Include Functions ############################

. functions.sh

#####################Environment PATH ####################################

path

### Define Variable Here ###############


CONFIG_FILE="/etc/ssh/sshd_config"
num_fields=2
typeset -i status=0

DATA_VAR="PermitRootLogin"
DATA_VAL="no"
DELIMITER=' '

# Make 'PermitRootLogin' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="Protocol"
DATA_VAL="2"
DELIMITER=' '

# Make 'Protocol' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="Banner"
DATA_VAL="/etc/issue"
DELIMITER=' '

# Make 'Banner' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="LogLevel"
DATA_VAL="INFO"
DELIMITER=' '

# Make 'LogLevel' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="X11Forwarding"
DATA_VAL="no"
DELIMITER=' '

# Make 'X11Forwarding' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="MaxAuthTries"
DATA_VAL="3"
DELIMITER=' '
# Make 'MaxAuthTries' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="HostbasedAuthentication"
DATA_VAL="no"
DELIMITER=' '
# Make 'HostbasedAuthentication' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="IgnoreRhosts"
DATA_VAL="yes"
DELIMITER=' '
# Make IgnoreRhosts compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="PermitEmptyPasswords"
DATA_VAL="no"
DELIMITER=' '

# Make 'MaxAuthTries' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


DATA_VAR="PermitUserEnvironment"
DATA_VAL="no"
DELIMITER=' '

# Make 'PermitUserEnvironment' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="PermitUserEnvironment"
DATA_VAL="no"
DELIMITER=' '

# Make 'PermitUserEnvironment' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="ClientAliveInterval"
DATA_VAL="300"
DELIMITER=' '

# Make 'ClientAliveInterval' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"

DATA_VAR="ClientAliveCountMax"
DATA_VAL="0"
DELIMITER=' '

# Make 'ClientAliveCountMax' compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL ' ' $num_fields "yes" "yes"


#!/bin/bash
#Title:MSS_RHEL-7_aide-fileintegrity-check.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

#Notes
#Periodic file checking allows the system administrator to determine on a regular basis if critical files have been changed in an unauthorized fashion
#The checking in this instance occurs every day at 5am. Alter the frequency and time of the checks in compliance with site policy.
############################################################

. functions.sh

#####################Export PATH #############################

path


####################### Define Variable Here #################


CRON_FILE="/var/spool/cron/root"


val=`grep -w "/usr/sbin/aide" $CRON_FILE | grep -v ^"#"`
if [ $? != 0 ]
then
	cecho "Adding Cronjob for file integrity check" yellow
	#Job scheduled to run the aide check.
        echo "0 5 * * * /usr/sbin/aide --check" >> $CRON_FILE

        # Restart cron, if necessary
        ps -ef | grep crond | grep -v grep > /dev/null
        if [ $? = 0 ]
        then
                 systemctl restart crond.service
        else
                 systemctl start crond.service
        fi
else
        cecho "Already Compliance with Colt Standard" green
	echo "$val"

fi


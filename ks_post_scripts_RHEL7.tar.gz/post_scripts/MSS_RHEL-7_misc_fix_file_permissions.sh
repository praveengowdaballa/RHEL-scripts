#!/bin/bash

#Title:MSS_RHEL-7_misc_fix_file_permissions.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

#####################Export PATH #############################

path

####################### Define Variable Here #################

XINETD_FILE="/etc/xinetd.conf"
XINETD_DIR="/etc/xinetd.d"
MSGS_FILE="/var/log/messages"



# check file permission for xinetd file/directory
expected_perm="750"
for afile in $XINETD_FILE $XINETD_DIR 
do
	current_perm=`stat $afile -c "%a"`
	if [ $current_perm != $expected_perm ]
	then
		chmod $expected_perm $afile
		 cecho "$afile file set with $expected_perm permission" yellow
        else
                cecho "$afile file has already $current_perm" green

	fi
done	

# check file permission for xinetd file/directory
expected_perm="640"
current_perm=`stat $MSGS_FILE -c "%a"`
if [ $current_perm != $expected_perm ]
then
	chmod $expected_perm $MSGS_FILE
	cecho "$MSGS_FILE file set with $expected_perm permission" yellow
else
	cecho "$MSGS_FILE file has already $current_perm" green
fi

# check file permission for grub.conf file/directory
expected_perm="600"
GRUB_FILE="/boot/grub2/grub.cfg"
current_perm=`stat $GRUB_FILE -c "%a"`
if [ $current_perm != $expected_perm ]
then
        chmod $expected_perm $GRUB_FILE
        cecho "$GRUB_FILE file set with $expected_perm permission" yellow
else
        cecho "$GRUB_FILE file has already $current_perm" green
fi

#Check AT file permission and remove cron.deny
at_file="/etc/at.deny"
if [ -f $at_file ]; then
cecho "Removing $at_file as per Security hardening" yellow
cp $at_file $at_file.`timestamp`
rm -f $at_file
else
cecho "Already $at_file removed" green
fi

at_file1="/etc/at.allow"
if [ ! -f $at_file1 ]; then
cecho "Creating $at_file1 as per the CIS security hardening-6.1.10 " yellow
touch $at_file1
else
cecho "Already $at_file1 is present" green
fi

cron_file="/etc/cron.deny"
if [ -f $cron_file ]; then
cecho "Removing $cron_file as per Security hardening" yellow
cp $cron_file $cron_file.`timestamp`
rm -f $cron_file
else
cecho "Already $cron_file removed" green
fi

cron_file1="/etc/cron.allow"
if [ ! -f $cron_file1 ]; then
cecho "Creating $cron_file1 as per the CIS security hardening-6.1.10 " yellow
touch $cron_file1
else
cecho "Already $cron_file1 is present" green
fi


# check file permission for cron file/directory
CRON_FILES="/etc/crontab /etc/cron.hourly /etc/cron.daily /etc/cron.weekly /etc/cron.monthly /etc/cron.d /etc/cron.allow /etc/at.allow /etc/ssh/sshd_config"
expected_perm="600"
for afile in $CRON_FILES
do
current_perm=`stat $afile -c "%a"`
if [ $current_perm != $expected_perm ]
then
        chmod $expected_perm $afile
        cecho "$afile file set with $expected_perm permission" yellow
else
        cecho "$afile file has already $current_perm" green
fi
done


# check files ownership
expected_ownership="root:root"
LIST_OF_CONFIG_FILES="/etc/issue /etc/securetty /etc/ssh/sshd_config /etc/resolv.conf /etc/sudoers"
for afile in $LIST_OF_CONFIG_FILES
do
	current_ownership=`stat $afile -c "%U:%G"`
	if [ $current_ownership != "$expected_ownership" ]
	then
		chown $expected_ownership $afile
		cecho "$afile file set with $expected_ownership ownership" yellow
	else
        	cecho "$afile file has already $expected_ownership ownership" green
	fi
done


# Fix SUID files
LIST_OF_EXEC_FILES="/bin/mount /bin/umount /bin/ping /bin/traceroute /usr/sbin/usernetctl /usr/bin/at" 
for afile in $LIST_OF_EXEC_FILES
do
        setuid_octal=`stat $afile -c "%a" | cut -c 1`
	if [ "$setuid_octal" = "4" ]
	then
		chmod u-s $afile 
		cecho "SUID removed from $afile" yellow
	else
		cecho "SUID already removed for $afile" green
        fi
done

#!/bin/bash

#Title:MSS_RHEL-7_set_TMOUT_values.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

#############################################################

. functions.sh

#####################Export PATH ############################

path

#######################Define Variable###############################
CONFIG_FILE="/etc/profile"
DATA_VAL="trap \"\" 1 2 3 15"
CONFIG_FILE1="/etc/screenrc"

grep -w "SCREENEXEC" $CONFIG_FILE > /dev/null
if [ $? -eq 1 ]
then
cecho "Updating config file for timeout setting" yellow
sed -i.bak`timestamp` '1i\'"$DATA_VAL"'\' $CONFIG_FILE

cat <<! >> $CONFIG_FILE
SCREENEXEC="screen"
if [ -w $(tty) ]; then
trap "exec $SCREENEXEC" 1 2 3 15
echo -n 'Starting session in 5 seconds'
sleep 5
exec $SCREENEXEC
fi
!

else

cecho "Timeout Already Compliance with Colt Standard..." green

fi


grep  -w "idle 120" $CONFIG_FILE1 > /dev/null
	if [ $? -eq 1 ]
	then
	cecho "Updating $CONFIG_FILE1 with \" idle 120 quit autodetach off\"" yellow
	echo "idle 120 quit autodetach off" >> $CONFIG_FILE1
	else
	cecho "$CONFIG_FILE1 has already \" idle 120 quit autodetach off\"" green
	fi


typeset -i count=0
typeset -i linenumber=0

if [ -f $CONFIG_FILE ];then
        ExpectedValue="umask 077"
        Currentvalue=`grep -e "umask 022" -e "umask 077" $CONFIG_FILE |sed -e 's/^[ \t]*//'|uniq`
                if [ "$Currentvalue" != "$ExpectedValue" ]
                then
                        cecho "Updating Config file $CONFIG_FILE ... with $ExpectedValue " yellow
                        sed -i -e 's/022/077/g' $CONFIG_FILE
			sed -i.bak.`timestamp` -e 's/002/027/g' $CONFIG_FILE
                        cecho "Updated ..." yellow
                elif [ "$Currentvalue" == "$ExpectedValue" ]
                then
                cecho "Umask value already restricted to $Currentvalue" green
                else
                cecho "Console Currently having this setting $Currentvalue" red
                fi
else
echo "Config file $file not present"
fi

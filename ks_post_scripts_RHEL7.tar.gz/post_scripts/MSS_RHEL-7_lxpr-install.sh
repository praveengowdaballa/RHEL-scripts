#!/bin/bash


#Appended by saravana 
######################## Include Functions ############################

. functions.sh

#####################Environment PATH ####################################

path



LXPR_SCRIPT="lxpr"
LXPR_README="README.lxpr-1.0.txt"
LXPR_ROOT_DIR="/opt/lxpr"
LXPR_BIN_DIR="$LXPR_ROOT_DIR/bin"
LXPR_LOG_DIR="/var/lxpr"
LXPR_DOC_DIR="$LXPR_ROOT_DIR/doc"
LXPR_SOURCE="/ColtExtras"
CRON_FILE="/var/spool/cron/root"
LXPR_SOURCE_FILE="rhel-explorer-83376-lxpr-1.1.zip"

#export PATH=$PATH:/bin:/usr/bin:/sbin:/usr/local:/usr/local/sbin


typeset -i curr_space=0
typeset -i tempspace=10
CRON_FILE="/var/spool/cron/root"

if [ ! -d "$LXPR_ROOT_DIR" ]
then
        mkdir $LXPR_ROOT_DIR
fi

# Check disk space.
# Needs a minimum of 100MB of temporary space to store the PSP zip file.
curr_space=`df -kP $LXPR_SOURCE | grep ^\/dev | awk '{print $4}'`
curr_space=`expr $curr_space \/ 1024`
if [ $curr_space -lt $tempspace ]
then
        cecho "The staging area ($LXPR_SOURCE) needs to have atleast $tempspace MB of disk space." red
        cecho "Current available space in $LXPR_SOURCE  filesystem is $curr_space ." red
        cecho "exiting...." red
        exit 1
fi


if [ -f "$LXPR_BIN_DIR/$LXPR_SCRIPT" ]
then
        cecho "$LXPR_BIN_DIR/$LXPR_SCRIPT already installed." green
        cecho "exiting..." green
        exit 1
fi

# create root's cron file if it doesn't exist
if [ ! -f $CRON_FILE ]
then
        touch $CRON_FILE
fi

grep -w "$LXPR_BIN_DIR/$LXPR_SCRIPT" $CRON_FILE | grep -v ^"#" > /dev/null
if [ $? = 0 ]
then
        cecho "cron entry already exist for $LXPR_BIN_DIR/$LXPR_SCRIPT in $CRON_FILE." red
        cecho "Please rectify this situation before installng this software." red
                echo "exiting..."
                exit 1
        fi


        if [ ! -d $LXPR_LOG_DIR ]
        then
                mkdir $LXPR_LOG_DIR
        fi

        if [ ! -d $LXPR_ROOT_DIR ]
        then
                mkdir $LXPR_ROOT_DIR $LXPR_BIN_DIR $LXPR_DOC_DIR
        else
                if [ ! -d $LXPR_BIN_DIR ]
                then
                        mkdir $LXPR_BIN_DIR
                fi

                if [ ! -d $LXPR_DOC_DIR ]
                then
                        mkdir $LXPR_DOC_DIR
                fi
fi


################# Copy Software lxpr ###################

if [ -f  $LXPR_SOURCE/$LXPR_SOURCE_FILE  ]
then
        cd $LXPR_SOURCE
        /usr/bin/unzip $LXPR_SOURCE_FILE
        if [ $? -eq 0 ];then echo "Extracting $LXPR_SOURCE_FILE successfull...";else echo "!!!Failed Extracting $LXPR_SOURCE_FILE !!!!";fi
fi

########################################################

if [ -f $LXPR_SOURCE/$LXPR_SCRIPT ]
then
        # copy lxpr script
        cp $LXPR_SOURCE/$LXPR_SCRIPT $LXPR_BIN_DIR/$LXPR_SCRIPT

        if [ $? != 0 ]
        then
                echo "copy of $LXPR_SOURCE/$LXPR_SCRIPT to $LXPR_BIN_DIR/$LXPR_SCRIPT failed."
                exit 1
        fi
else
        echo "$LXPR_SOURCE/$LXPR_SCRIPT not found."
        exit 1
fi

if [  -f $LXPR_SOURCE/$LXPR_README ]
then
        # copy README file

        cp $LXPR_SOURCE/$LXPR_README $LXPR_DOC_DIR/$LXPR_README
        if [ $? != 0 ]
        then
                echo "copy of $LXPR_SOURCE/$LXPR_README to $LXPR_DOC_DIR/$LXPR_README failed."
                exit 1
        fi
else
        echo "$LXPR_SOURCE/$LXPR_README not found."
        exit 1
fi

# set permission/owenership
chmod 744 $LXPR_BIN_DIR/$LXPR_SCRIPT
chown root:root $LXPR_BIN_DIR/$LXPR_SCRIPT

grep -w "$LXPR_BIN_DIR/$LXPR_SCRIPT" $CRON_FILE | grep -v ^"#" > /dev/null
if [ $? != 0 ]
then
        # Run one-off job
        #nohup $LXPR_BIN_DIR/$LXPR_SCRIPT -st $LXPR_LOG_DIR 2>&1 > /dev/null &
                     #nohup  /opt/lxpr/bin/lxpr -st /var/lxpr 2>&1 > /dev/null

        #lxpr weekly cron job
        echo "0 1 * * 0 $LXPR_BIN_DIR/$LXPR_SCRIPT -st $LXPR_LOG_DIR" >> $CRON_FILE
        #lxpr monthly job to clear down old dumps
        echo "0 1 28 * * find $LXPR_LOG_DIR -name \"lxpr.\`uname -n\`*\" -type d -a -mtime +30 -exec /bin/rm -r {} \;" >> $CRON_FILE


        # Restart cron, if necessary
        ps -ef | grep crond | grep -v grep > /dev/null
        if [ $? = 0 ]
        then
		 systemctl restart crond.service
        else
		 systemctl start crond.service
        fi
else
        exit 1

fi

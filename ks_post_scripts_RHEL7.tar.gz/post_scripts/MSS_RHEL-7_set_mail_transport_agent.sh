#!/bin/bash

#Title:MSS_RHEL-7_set_mail_transport_agent.sh
#Author:Saravana.kannayan@colt.net
#Version:1.0

############################################################

. functions.sh

################## Export PATH #############################

path

##################### Define Variable Here #################
	
MTA_EXEC=`get_user_input "MTA_EXEC"`
        if [ -z $MTA_EXEC ]
        then
        cecho "MTA_EXEC not set. using default " yellow
        MTA_EXEC="/usr/sbin/sendmail.postfix"
        fi

ALTERNATIVES="/usr/sbin/alternatives"

#MTA_EXEC="/usr/sbin/sendmail.postfix"
		
CURR_MTA_EXEC="`$ALTERNATIVES --display mta | grep "link currently points" | awk '{print $NF}'`"

if [ "$MTA_EXEC" != "$CURR_MTA_EXEC" ]
then
	
	if [ -x "$MTA_EXEC" ]
	then
		$ALTERNATIVES --set mta "$MTA_EXEC"
		if [ $? != 0 ]
		then
			cecho "Mail Transport Agent is still pointing to $CURR_MTA_EXEC" red
			cecho "This should be set to $MTA_EXEC" red
			exit 1
		fi
	else
	cecho "Mail Transport Agent is set to $MTA_EXEC" green

	fi
else

cecho "Mail Transport Agent is already set to $MTA_EXEC" green

fi


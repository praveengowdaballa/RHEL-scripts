#!/bin/bash

#Title:MSS_RHEL-7_disable_ipv6.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

#############################################################

. functions.sh

#####################Export PATH ############################

path

#######################Define Variable###############################

CONFIG_FILE="/etc/sysconfig/network"
num_fields=2
typeset -i status=0
DATA_VAR="NOZEROCONF"
DATA_VAL="yes"
DELIMITER=' '

# Make NOZEROCONF compliant,  if necessary
make_compliant $CONFIG_FILE "$DATA_VAR" $DATA_VAL '=' $num_fields "yes" "yes"

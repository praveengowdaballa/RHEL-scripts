#!/bin/bash 
#Title:MSS_RHEL-7_disable_control-alt-delete_services.sh
#Author:saravana.kannayan@colt.net
#Version:1.0

#####################Export PATH #############################

export PATH=$PATH:/bin:/usr/bin:/sbin:/usr/local:/usr/local/sbin

######################## Include Functions ###################

. functions.sh


####################### Define Variable Here #################


check=`systemctl list-unit-files |grep del |awk '{print $2}'`

	if [ $check = masked ]
		then
		cecho "ctrl-alt-del target is already masked....Compliance with Colt Standard" green
		else
			cecho "ctrl-alt-del target is not masked.. Not Compliance with Colt Standard" red
			 #Note: Masking the ctrl-alt-del service,which is equal to disabling service in RHEL6
			 ln -sf /dev/null /etc/systemd/system/ctrl-alt-del.target
			 rc=`echo $?`
			 if [ $rc = 0 ]
				 then
				 cecho "ctrl-alt-del target is disabled successfully...." green
				 else
					 cecho "Unable to mask ctrl-alt-del target, Have a look manually" red
	 		 fi
	fi
	


